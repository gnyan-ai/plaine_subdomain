def image_data(image_path):
    import base64
    with open(image_path, "rb") as f:
        data = f.read()
        encoded = base64.b64encode(data)
    data = "data:image/png;base64," + encoded.decode("utf-8")
    return data

def hide_footer():
    import streamlit as st
    # Set sidebar state to false/hidden by default and set page width to wide
    st.set_page_config(page_title="Analytics Hub", layout="wide", initial_sidebar_state="collapsed")
    # Hide footer and hamburger menu
    hide_streamlit_style = """
                <style>
                footer {visibility: hidden;}
                /* Add custom text at the bottom right */
                .custom-footer {
                    position: fixed;
                    right: 15px;
                    bottom: 10px;
                    z-index: 100;
                    background-color: transparent;
                    color: lightgray;
                    font-size: 16px;
                }
                </style>
                """
    st.markdown(hide_streamlit_style, unsafe_allow_html=True)

def update_ollama_status():
    import os
    import requests
    import streamlit as st
    if not hasattr(st.session_state, "llm_status"):
        st.session_state.llm_status = False
    ollama_host = os.environ.get("OLLAMA_HOST", "http://192.168.27.10:11434")
    # Define the URL for the Ollama health check
    ollama_health_url = f"{ollama_host}"
    # Make an HTTP GET request to the Ollama health endpoint
    ollama_health_response = requests.get(ollama_health_url)
    # Check if the response is successful (status code 200)
    if ollama_health_response.status_code == 200:
        ollama_status = "Ollama is running"
        status_icon = "✅"  # Green tick emoji
        st.session_state.llm_status = True
    else:
        ollama_status = "Ollama is not running"
        status_icon = "❌"  # Red cross emoji
        st.session_state.llm_status = False
    # Display the status icon and status message in the Streamlit sidebar
    st.markdown(f"""<div class="custom-footer">{status_icon} {ollama_status}</div>""", unsafe_allow_html=True)