from contextlib import contextmanager
import pandas as pd
import os
import json
import hashlib
import concurrent.futures
import functools
import pmdarima
from sqlalchemy import create_engine, text
from .datalake_utils import execute_trino_query
from .llm_utils import llm_decorator
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import streamlit as st

dbname = 'databases.db'
sqldb = f'sqlite:///{dbname}'
empty_frame = pd.DataFrame([], columns=['table_hash', 'table_schema', 'table_name', 'column_name', 'ordinal_position', 'column_default', 'is_nullable', 'data_type', 'columns', 'table_description', 'sample_values', 'column_description'])

@contextmanager
def sqlite_db_connection(commit=True):
    conn = create_engine(sqldb).connect()
    try:
        yield conn
    except Exception as e:
        print(f"Exception: {e}")
        pass
    finally:
        if commit:
            conn.commit()
        conn.close()
        
# Create a SQLLite3 database to store the table metadata
def create_table_metadata_db():
    if not os.path.exists(dbname):
        print(f"Creating table_metadata database: {os.path.exists(dbname)}")
        with sqlite_db_connection() as conn:
            empty_frame.to_sql('table_metadata', conn, if_exists='replace', index=False)

# Create a idempotent hashing function that generates a unique name for a table given a table_schema and table_name
def generate_table_hash(*args):
    # use md5 hash to generate a unique name
    return hashlib.md5(''.join(map(str,args)).encode('utf-8')).hexdigest()

def pandas_update(seconds):
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            with concurrent.futures.ThreadPoolExecutor() as executor:
                create_table_metadata_db()
                pdf = get_catalog()
                # Remember original pandas frame contents by computing a natural hash key of 'table_catalog', 'table_schema', 'table_name', 'column_name', 'ordinal_position', 'column_default', 'is_nullable', 'data_type'
                crc_checks = {generate_table_hash(x.table_schema, x.table_name, x.column_name, x.ordinal_position, x.column_default, x.is_nullable, x.data_type):generate_table_hash(x.columns, x.table_description, x.sample_values, x.column_description) for i, x in pdf.iterrows()}
                args = (pdf,) + args
                future = executor.submit(func, *args, **kwargs)
                try:
                    return future.result(timeout=seconds)
                except concurrent.futures.TimeoutError:
                    raise TimeoutError(f"Timed out after {seconds} seconds")
                finally:
                    # Update, delete, or insert rows that have been added to the pdf. Compute changes by hash compare from before
                    crc_checks_2 = {
                        generate_table_hash(
                            x.table_schema,
                            x.table_name,
                            x.column_name,
                            x.ordinal_position,
                            x.column_default,
                            x.is_nullable,
                            x.data_type,
                        ): generate_table_hash(
                            x.columns, x.table_description, x.sample_values, x.column_description
                        )
                        for i, x in pdf.iterrows()
                    }

                    # Create an SQLite database engine and establish a connection
                    # Update rows that have changed
                    for k, v in crc_checks_2.items():
                        if k in crc_checks and crc_checks[k] != v:
                            # Update the row
                            latest_data_row = pdf[pdf.table_hash == str(k)].head(1)
                            if len(latest_data_row):
                                update_query = text(
                                    """
                                    UPDATE table_metadata
                                    SET columns = :columns,
                                        table_description = :table_description,
                                        sample_values = :sample_values,
                                        column_description = :column_description
                                    WHERE table_hash = :table_hash
                                    """
                                )
                                try:
                                    with sqlite_db_connection() as conn:
                                        conn.execute(
                                            update_query,
                                            latest_data_row.iloc[0].to_dict()                                        
                                        )
                                except Exception as e:
                                    print(f"Exception: {e}")
                                    pass

                    # Delete rows that have been deleted
                    for k, v in crc_checks.items():
                        if k not in crc_checks_2:
                            delete_query = text("DELETE FROM table_metadata WHERE table_hash = :table_hash")
                            with sqlite_db_connection() as conn:
                                conn.execute(delete_query, table_hash=k)

                    # Insert rows that have been added
                    for k, v in crc_checks_2.items():
                        if k not in crc_checks:
                            latest_data_row = pdf[pdf.table_hash == str(k)].head(1)
                            if len(latest_data_row):
                                print(f"Inserting row: {latest_data_row}")
                                insert_query = text(
                                    """
                                    INSERT INTO table_metadata
                                    VALUES (
                                        :table_hash,
                                        :table_schema,
                                        :table_name,
                                        :column_name,
                                        :ordinal_position,
                                        :column_default,
                                        :is_nullable,
                                        :data_type,
                                        :columns,
                                        :table_description,
                                        :sample_values,
                                        :column_description
                                    )
                                    """
                                )
                                with sqlite_db_connection() as conn:
                                    conn.execute(
                                        insert_query,
                                        {
                                            "table_hash": k,
                                            "table_schema": latest_data_row.table_schema.tolist()[0],
                                            "table_name": latest_data_row.table_name.tolist()[0],
                                            "column_name": latest_data_row.column_name.tolist()[0],
                                            "ordinal_position": latest_data_row.ordinal_position.tolist()[0],
                                            "column_default": latest_data_row.column_default.tolist()[0],
                                            "is_nullable": latest_data_row.is_nullable.tolist()[0],
                                            "data_type": latest_data_row.data_type.tolist()[0],
                                            "columns": latest_data_row["columns"].tolist()[0],
                                            "table_description": latest_data_row.table_description.tolist()[0],
                                            "sample_values": latest_data_row.sample_values.tolist()[0],
                                            "column_description": latest_data_row.column_description.tolist()[0]
                                        }
                                    )

        return wrapper
    return decorator

def refresh_schema(schema='default'):
    warehouse_ddl = execute_trino_query(f"""select "table_schema", "table_name", "column_name", "ordinal_position", "column_default", "is_nullable", "data_type" from information_schema.columns where table_schema = '{schema}' order by table_schema, table_name, ordinal_position""")
    if warehouse_ddl is not None:
        # Add empty columns for any columns missing in warehouse_ddl but present in empty_frame
        for col in empty_frame.columns:
            if col not in warehouse_ddl.columns:
                warehouse_ddl[col] = None 
        warehouse_ddl['table_hash'] = warehouse_ddl.apply(lambda x: generate_table_hash(x.table_schema, x.table_name, x.column_name, x.ordinal_position, x.column_default, x.is_nullable, x.data_type), axis=1)
    init_table = warehouse_ddl if warehouse_ddl is not None else empty_frame
    with sqlite_db_connection() as conn:
        init_table.to_sql('table_metadata', conn, if_exists='replace', index=False)
    return init_table


def get_table_column_sample(table_name, column_name, schema='default', n=5):
    sample = execute_trino_query(f"""select cast(array_agg("{column_name}") as json) sample_values from (select "{column_name}" from "{schema}"."{table_name}" tablesample bernoulli ({n}) limit {n}) x""")
    return sample.sample_values[0] if sample is not None and len(sample) > 0 else None

@pandas_update(60)
def update_sample(pdf):
    pdf['sample_values'] = pdf.apply(lambda x: x['sample_values'] if pd.notna(x['sample_values']) else get_table_column_sample(x['table_name'], x['column_name'], x['table_schema'], 5), axis=1)
    

@llm_decorator()
def generate_table_description(llm, table_schema, table_name, columns, **kwargs):
    from langchain.chains import LLMChain
    from langchain.prompts import PromptTemplate
    content_string = """You are an EXPERT data analyst.
You are given a schema name, a table name, and a list of columns in the table.
The schema name is a string.
The table name is a string.
The list of columns is a list of strings in JSON format.
You are to write a short description of the table in 5 sentences or less.
YOU ARE NOT ALLOWED to produce any binary or non-text content.
YOU ARE ALLOWED to be creative in your interpretation of the column.
YOU ARE NOT ALLOWED to hallucinate however. Do NOT make up data or non-existent columns.
You MUST respond with a string description ONLY, nothing extra, preferably in a single line not to exceed 300 characters.
Surround response in backticks ```.
    Example Input: {{'schema': 'default', 'table': 'customer', 'columns': ['customer_id:integer', 'customer_age':decimal, 'customer_dob:date', 'customer_name:varchar', 'customer_address:varchar', 'customer_phone:varchar', 'customer_email:varchar']}}
    Example Output: ```The table is a list of customers. Each customer has a unique customer_id, a name, a residential address, contact phone, and a business email.```

Analyze deeply: take a deep breath and be exhaustive in your analysis.
Please analyze and describe the table in 5 sentences or less. Use the following JSON as your input:
    {{schema: '{schema}', table: '{table}', columns: {columns}}}

Description:```
"""
    from langchain.schema.runnable import RunnablePassthrough, RunnableLambda
    from langchain.chains import LLMChain
    file_llm_chain = LLMChain(
        llm=llm,
        prompt=PromptTemplate.from_template(content_string),
        verbose=True,
    )
    result = file_llm_chain.invoke(input={'schema':table_schema, 'table':table_name, 'columns':json.dumps(columns)})
    return result['text']

# Get the pandas from sqlite
def get_catalog():
    if not os.path.exists(dbname):
        refresh_schema()
    else:
        create_table_metadata_db()
    with sqlite_db_connection() as conn:
        return pd.read_sql('select * from table_metadata', conn)

@st.cache_data
def get_stocks():
    return execute_trino_query(f"""select * from default.s_and_p_5_years""")

@st.cache_data
def analyze_temporal_trend(df, temporal_col, measure_cols, historic_cutover_date, start_date, end_date, temporal_grain='1w', agg_metric='mean', groupby_cols=None):
    # Convert the temporal column to datetime
    df[temporal_col] = pd.to_datetime(df[temporal_col])
    # Resample the dataframe to the desired temporal frequency (e.g., daily, weekly)
    df.set_index(temporal_col, inplace=True)
    group_cols = groupby_cols if groupby_cols is not None else []
    df_resampled = df.groupby([pd.Grouper(freq=temporal_grain)] + group_cols).agg({col: agg_metric for col in measure_cols}).reset_index().set_index(temporal_col)
    # Filter the dataframe for the historic and current periods
    df_historic = df_resampled[(df_resampled.index >= pd.to_datetime(start_date)) & (df_resampled.index <= pd.to_datetime(historic_cutover_date))]
    df_current = df_resampled[(df_resampled.index > pd.to_datetime(historic_cutover_date)) & (df_resampled.index < pd.to_datetime(end_date))]
    df_historic.index = pd.to_datetime(df_historic.index)
    df_current.index = pd.to_datetime(df_current.index)
    # Calculate the aggregate measure for the historic and current periods
    if not group_cols:
        historic_agg = df_historic[measure_cols].agg(agg_metric)
        current_agg = df_current[measure_cols].agg(agg_metric)
    else:
        historic_agg = df_historic.groupby(group_cols)[measure_cols].agg(agg_metric)
        current_agg = df_current.groupby(group_cols)[measure_cols].agg(agg_metric)
    # Calculate the percentage change between historic and current aggregates
    pct_change = ((current_agg - historic_agg) / historic_agg) * 100
    # Create DataFrames for each measure column with labels
    triplets = pd.concat([historic_agg, current_agg, pct_change], axis=1, keys=['Historic', 'Current', 'Percentage Change'])
    return triplets

@st.cache_data
def analyze_temporal_trend_arima(df, temporal_col, measure_cols, historic_cutover_date, start_date, end_date, temporal_grain='1w', agg_metric='mean', groupby_cols=None):
    results = pd.DataFrame()

    # Convert the temporal column to datetime
    df[temporal_col] = pd.to_datetime(df[temporal_col])

    if not groupby_cols:
        groupby_cols = ['group']
        df['group'] = 'all'

    # Iterate through each measure column
    for measure_col in measure_cols:
        measure_results = []
        
        # Group the dataframe by dimensional series and iterate
        groups = df.groupby(groupby_cols)
        for group_name, group_data in groups:
            # Resample the dataframe to the desired temporal frequency (e.g., daily, weekly)
            group_data.set_index(temporal_col, inplace=True)

            df_resampled = group_data.groupby([pd.Grouper(freq=temporal_grain)]).agg({measure_col: agg_metric})

            df_historic = df_resampled[(df_resampled.index >= pd.to_datetime(start_date)) & (df_resampled.index <= pd.to_datetime(historic_cutover_date))]
            
            df_current = df_resampled[(df_resampled.index > pd.to_datetime(historic_cutover_date)) & (df_resampled.index < pd.to_datetime(end_date))]

            # Resample the index to a datetime index, not a unix timestamp index
            df_historic.index = pd.to_datetime(df_historic.index)
            df_current.index = pd.to_datetime(df_current.index)

            try:
                # Train an AutoARIMA model for the current measure column
                model = pmdarima.auto_arima(df_historic[measure_col], seasonal=True, stepwise=True, trace=False)

                # Predict values for the current window (outside of historic data)
                predicted_values = model.predict(n_periods=len(df_current[df_current.index > df_historic.index.max()]))
            except:
                predicted_values = np.zeros(len(df_current[df_current.index > df_historic.index.max()]))

            # Reset the index of actual values to align with predicted values
            actual_values = df_current[df_current.index > df_historic.index.max()][measure_col]

            # Calculate percentage change between actual and predicted
            pct_change = ((actual_values - predicted_values) / predicted_values) * 100
            
            pdf = pd.DataFrame(zip(actual_values, predicted_values, pct_change), columns=['Actual', 'Predicted', 'Percentage Change'], index=actual_values.index)
            pdf['Dimensional_Series'] = [group_name for _ in actual_values.index]
            pdf['Measure_Column'] = [measure_col for _ in actual_values.index]
            results = pd.concat([results, pdf])

    return results

@pandas_update(60)
def update_table_columns(pdf):
    cdf = pdf.drop_duplicates(subset=['table_schema', 'table_name', 'column_name', 'ordinal_position']).sort_values(by=['table_schema', 'table_name', 'ordinal_position']).groupby(['table_schema', 'table_name']).apply(lambda x: str(x['column_name'].tolist())).reset_index().rename(columns={0:'columns'})
    # Make a dict with table schema and table name as key and columns as value
    column_mapping = {}
    for i, x in cdf.iterrows():
        column_mapping[f"{x.table_schema}.{x.table_name}"] = x.columns
    # Now update the pdf with the columns
    pdf['columns'] = pdf.apply(lambda x: x['columns'] if pd.notna(x['columns']) else column_mapping[f"{x.table_schema}.{x.table_name}"], axis=1)

@pandas_update(60)
def update_table_description(pdf, md_output=None):
    cdf = pdf.drop_duplicates(subset=['table_schema', 'table_name'])
    # Make a dict with table schema and table name as key and columns as value
    column_mapping = {}
    for i, x in cdf.iterrows():
        column_mapping[f"{x.table_schema}.{x.table_name}"] = x['table_description'] if pd.notna(x['table_description']) else generate_table_description(x['table_schema'], x['table_name'], x['columns'], md_output=md_output)
    pdf['table_description'] = pdf.apply(lambda x: x['table_description'] if pd.notna(x['table_description']) else column_mapping[f"{x.table_schema}.{x.table_name}"], axis=1)

@llm_decorator()
def generate_column_description(llm, table_schema, table_name, table_description, columns, column, samples, **kwargs):
    from langchain.chains import LLMChain
    from langchain.prompts import PromptTemplate
    content_string = """You are an EXPERT data analyst.
You are given a schema name, a table name, a table description that you inferred priorly, a list of columns in the table, and finally -- ONE of those columns that is our analysis target. You will also be presented a few samples of the target column value in JSON format.
The schema name is a string.
The table name is a string.
The table description is a string.
The list of columns is a list of strings in JSON format.
The target column name is a string.
The target column samples is a list in JSON format.

Based on your in-depth analysis of the table, table description, target column (and any inherent relationship of the target column with other columns in the table), you are to write a short column description of the target column in 3 sentences or less.
YOU ARE NOT ALLOWED to produce any binary or non-text content.
YOU ARE ALLOWED to be creative in your interpretation of the column.
YOU ARE NOT ALLOWED to hallucinate. Do NOT make up data or non-existent columns.
YOU MUST respond with a string description ONLY, nothing extra, preferably in a single line not to exceed 300 characters.
YOU MUST embed the target column name within the output description inside backticks: for example: `{{target_column}}`: PLEASE COMPLY.
Surround response in three backticks ```.
    Example Input: {{'schema': 'default', 'table': 'customer', 'table_description':'Customer master data information', 'columns': ['customer_id:integer', 'customer_age':decimal, 'customer_dob:date', 'customer_name:varchar', 'customer_address:varchar', 'customer_phone:varchar', 'customer_email:varchar'], 'target_column': 'customer_name', 'target_column_samples': ['John Doe', 'Jane Doe', 'Jack Doe']}}
    Example Output: ```The `customer_name` is a string that contains the first, middle, and last names of the customer concatenated in a FML format.```

Analyze deeply: take a deep breath and be exhaustive in your analysis.
Please analyze and describe the table in 3 sentences or less. Use the following JSON as your input:
    {{schema: '{schema}', table: '{table}', table_description: {table_description}, columns: {columns}, target_column: '{column}', target_column_samples: {samples}}}

Column Description:```
"""
    from langchain.schema.runnable import RunnablePassthrough, RunnableLambda
    from langchain.chains import LLMChain
    file_llm_chain = LLMChain(
        llm=llm,
        prompt=PromptTemplate.from_template(content_string),
        verbose=True,
    )
    return file_llm_chain.invoke(input={'schema':table_schema, 'table':table_name, 'table_description': table_description, 'columns':json.dumps(columns), 'column':column, 'samples':json.dumps(samples)},)['text']

@pandas_update(60)
def update_column_description(pdf, md_output=None):
    pdf['column_description'] = pdf.apply(lambda x: x['column_description'] if pd.notna(x['column_description']) else generate_column_description(x['table_schema'], x['table_name'], x['table_description'], x['columns'], x['column_name'], x['sample_values'], md_output=md_output), axis=1)

@llm_decorator()
def get_temporal(llm, df, **kwargs):
    from langchain.chains import LLMChain
    from langchain.prompts import PromptTemplate
    temporal_string = """You are an EXPERT business analyst. You MUST use your analytical skills to analyze the tabular data presented in the context and determine the ONE temporal attribute of the table that can be used to analyze trends in the data.
The temporal attribute must be of coercable into a date, a time, or a datetime data type. We will be using this attribute to measure ToT (day-over-day, week-over-week, month-over-month, quarter-over-quarter, year-over-year) trends in the data.
The tabular information is presented in JSON format (only three rows). You will ONLY respond with the name of the temporal attribute in a single line not to exceed 64 characters.
For example, for tabular info like: '''[{{'sales_date': '2021-01-01', 'sales': 100}}, {{'sales_date': '2021-01-02', 'sales': 200}}, {{'sales_date': '2021-01-03', 'sales': 300}}]''', your response will be ```sales_date```.
If you do not have sufficient information to determine the temporal attribute, you MUST respond with ```None```.
Tabular Information: '''{context}'''
Temporal Attribute:```
"""
    from langchain.schema.runnable import RunnablePassthrough, RunnableLambda
    from langchain.chains import LLMChain
    temporal_llm = LLMChain(
        llm=llm,
        prompt=PromptTemplate.from_template(temporal_string),
        verbose=True,
    )
    return temporal_llm.invoke({'context':df.head(3).to_json(orient='records')})['text']

@llm_decorator()
def get_dimensional(llm, df, temporal_attribute, **kwargs):
    from langchain.chains import LLMChain
    from langchain.prompts import PromptTemplate
    temporal_string = """You are an EXPERT business analyst. You MUST use your analytical skills to analyze the tabular data presented in the context and determine an optional set of dimensional attributes in the table that can be used to analyze trends in the data.
The dimensional attributes are usually categorical attributes in the dataset that are aggregated over a temporal attribute.
The tabular information is presented in JSON format (only three rows). Its possible that the dataset may NOT have dimensional attributes. You will ONLY respond with the list of names of the dimensional attributes in a single line as a list not to exceed 6 attributes at most. Its obvious that a temporal attribute cannot ALSO be a dimensional attribute.
For example, for tabular info like: '''[{{'sales_date': '2021-01-01', 'region':'NA', 'sales_rep':'Chris', 'sales': 100}}, {{'sales_date': '2021-01-02', 'region':'SA', 'sales_rep':'Antonio', 'sales': 200}}, {{'sales_date': '2021-01-03', 'region':'NA', 'sales_rep':'Mike', 'sales': 300}}]''' with a temporal attribute as ```sales_date```, your response will be ```['region', 'sales_rep']```.
If you do not have sufficient information to determine the dimensional attribute, you MUST respond with ```[]```.
Tabular Information: '''{context}'''
Temmporal Attribute: ```{temporal_attribute}```
Dimensional Attributes:```
"""
    from langchain.schema.runnable import RunnablePassthrough, RunnableLambda
    from langchain.chains import LLMChain
    temporal_llm = LLMChain(
        llm=llm,
        prompt=PromptTemplate.from_template(temporal_string),
        verbose=True,
    )
    return temporal_llm.invoke({'context':df.head(3).to_json(orient='records'), 'temporal_attribute': temporal_attribute})['text']

@llm_decorator()
def get_measures(llm, df, temporal_attribute, dimensional_attributes, **kwargs):
    from langchain.chains import LLMChain
    from langchain.prompts import PromptTemplate
    temporal_string = """You are an EXPERT business analyst. You MUST use your analytical skills to analyze the tabular data presented in the context and determine a list of metric attributes in the table that can be used to analyze temporal trends.
The metrics/measures are usually numerical. We will be using these attributes to study ToT (day-over-day, week-over-week, month-over-month, quarter-over-quarter, year-over-year) trends.
The tabular information is presented in JSON format (only three rows). You will ONLY respond with the list of metrics/measures in a single line not to exceed 64 characters.
For example, for tabular info like: '''[{{'sales_date': '2021-01-01', 'region':'NA', 'sales_rep':'Chris', 'sales': 100}}, {{'sales_date': '2021-01-02', 'region':'SA', 'sales_rep':'Antonio', 'sales': 200}}, {{'sales_date': '2021-01-03', 'region':'NA', 'sales_rep':'Mike', 'sales': 300}}]''' with a temporal attribute as ```sales_date``` and dimensional attributes as ```['sales_rep', 'region']```, your response will be ```['sales']```.
If you do not have sufficient information to determine the measures, you MUST respond with ```[]```.
Tabular Information: '''{context}'''
Temmporal Attribute: ```{temporal_attribute}```
Dimensional Attributes:```{dimensional_attributes}```
Measures:```
"""
    from langchain.schema.runnable import RunnablePassthrough, RunnableLambda
    from langchain.chains import LLMChain
    temporal_llm = LLMChain(
        llm=llm,
        prompt=PromptTemplate.from_template(temporal_string),
        verbose=True,
    )
    return temporal_llm.invoke({'context':df.head(3).to_json(orient='records'), 'temporal_attribute': temporal_attribute, 'dimensional_attributes':dimensional_attributes})['text']