import trino
import pandas as pd

host = '192.168.27.10'
port = 8080  # Default Trino port
user = 'admin'
catalog = 'minio'
schema = 'default'

def execute_trino_query(query):
    try:
        # Establish a connection to Trino
        conn = trino.dbapi.connect(host=host, port=port, user=user, catalog=catalog, schema=schema)

        # Use pandas.read_sql() to fetch data directly into a DataFrame
        df = pd.read_sql(query, conn)

        return df

    except Exception as e:
        print(f"Error executing query: {str(e)}")
        return None
