import shutil
import streamlit as st
import os, json, pandas as pd, time
from .catalog_utils import refresh_schema, dbname, get_catalog, update_table_columns, update_sample, update_table_description, update_column_description
from .data_search_utils import create_vectorstore, search_columns, search_catalog_chain

def show():
    # Center align the header
    from .llm_utils import get_llm, StreamlitMarkdownProgressHandler

    st.markdown(f"<h1 style='text-align: center;'>Annotated Catalog</h1>", unsafe_allow_html=True)
    st.header("", divider=True)
    if not hasattr(st.session_state, "dataset"):
        st.session_state.dataset = None

    with st.spinner("Loading..."):
        st.session_state.dataset = get_catalog()
        print(st.session_state.dataset)
    
    if st.session_state.dataset is not None:
        st.sidebar.subheader("Metadata", divider=True)
        st.sidebar.markdown(f"**{len(st.session_state.dataset)}** attributes found in the catalog")
        st.sidebar.dataframe(st.session_state.dataset[['table_schema', 'table_name', 'column_name', 'table_hash']].describe(include='all'))

        console_out = st.empty()
        tbl = st.container()
        with tbl:
            frame = tbl.empty()
            btn = tbl.empty()
            llm_output = tbl.empty()
            # Show the button only if any of the table descriptions, column descriptions, or sample data is empty
            if any(st.session_state.dataset[['column_description', 'table_description', 'sample_values', 'columns']].isna().values.ravel().tolist()):
                frame.dataframe(st.session_state.dataset, height=400, use_container_width=True)
                button = btn.button('Annotate', help="Click to allow AI to analyze and auto-annotate your lakehouse attributes")
                if button:
                    console_out = st.progress(0.0)
                    frame.empty()
                    btn.empty()
                    llm_output.empty()
                    with st.spinner('Processing...'):
                        console_out.progress(0.0, "Updating columns...")
                        update_table_columns()
                        st.session_state.dataset = get_catalog()
                        frame.dataframe(st.session_state.dataset)
                        console_out.progress(0.2, "Collecting column samples...")
                        update_sample()
                        st.session_state.dataset = get_catalog()
                        frame.dataframe(st.session_state.dataset)
                        console_out.progress(0.4, "Updating table descriptions...")
                        update_table_description()
                        st.session_state.dataset = get_catalog()
                        frame.dataframe(st.session_state.dataset)
                        console_out.progress(0.6, "Updating column descriptions...")
                        update_column_description()
                        st.session_state.dataset = get_catalog()
                        frame.dataframe(st.session_state.dataset)
                        console_out.progress(0.8, "Creating index of the catalog...")
                        frame.dataframe(st.session_state.dataset)
                        create_vectorstore(st.session_state.dataset)
                        console_out.progress(1.0, "Prepared search index")
                        console_out.empty()
            else:
                frame.data_editor(st.session_state.dataset)
                create_vectorstore(st.session_state.dataset)

    st.header("Actions", divider=True)
    col1, col3, col2 = st.columns(3)
    status = st.empty()
    with col1:
        reload = col1.button("Hard delete and reload the catalog", key="Reload Catalog")
        if reload:
            with st.spinner("Loading..."):
                if os.path.exists(dbname):
                    os.remove(dbname)
                    status.success("Removing prior data", icon="✅")
                st.session_state.dataset = None
    with col3:
        refresh = col3.button("Soft refresh metadata", key="Refresh Catalog")
        if refresh:
            st.session_state.dataset = None
            status.success("Refreshing catalog", icon="⏳")

    with col2:
        reindex = col2.button("Reindex Catalog", key="Wipe and reindex")
        if reindex:
            if os.path.exists("./chroma_db"):
                shutil.rmtree("./chroma_db")
                create_vectorstore(st.session_state.dataset)
                status.success("Removed previous index", icon="✅") # delete icon

    with status:
        time.sleep(1)
        status.empty()
# Execute the main function
if __name__ == "__main__":
    show()    