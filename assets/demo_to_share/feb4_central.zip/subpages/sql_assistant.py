from contextlib import contextmanager
import shutil
from sqlalchemy import create_engine
import streamlit as st
from sql_formatter.core import format_sql
import os, json, pandas as pd, time
from .catalog_utils import refresh_schema, dbname, get_catalog, update_table_columns, update_sample, update_table_description, update_column_description
from .data_search_utils import create_vectorstore, search_columns, sql_chain

def show():
    # Center align the header
    from .llm_utils import get_llm, StreamlitMarkdownProgressHandler

    st.markdown(f"<h1 style='text-align: center;'>Datalake SQL Assistant</h1>", unsafe_allow_html=True)
    st.header("", divider=True)
    if not hasattr(st.session_state, "dataset"):
        st.session_state.dataset = None

    with st.spinner("Loading..."):
        st.session_state.dataset = get_catalog()
    
    if st.session_state.dataset is not None:
        st.sidebar.subheader("Metadata", divider=True)
        st.sidebar.markdown(f"**{len(st.session_state.dataset)}** attributes found in the catalog")
        st.sidebar.dataframe(st.session_state.dataset[['table_schema', 'table_name', 'column_name', 'table_hash']].describe(include='all'))

        console_out = st.empty()
        def clear_chat_history():
            st.session_state.sqls = []

        if "sqls" not in st.session_state:
            st.session_state.sqls = []

        sql_assistant_container = st.container()
        if os.path.exists('chroma_db'):
            with sql_assistant_container:
                sql_assistant_container.header("Extract Reports", anchor="sql-catalog", divider=True)
                with st.form("sql_assistant"):
                    question = st.text_input("What do you seek?", value="Tallest 10 airports in South America", help="Enter a SQL query to extract data from the datalake")
                    submit_button = st.form_submit_button(label='Generate', help="Click to generate a SQL query")
                    if submit_button:
                        md = sql_assistant_container.container()
                        if question:
                            with st.spinner('Processing...'): #
                                table_results = search_columns(question, k=10)
                                if table_results:
                                    pdf_results = pd.DataFrame.from_dict([result.metadata for result in table_results]).reset_index()[['table_schema', 'table_name', 'column_name', 'table_description', 'columns', 'column_description']]
                                else:
                                    pdf_results = pd.DataFrame()

                                def transform_group(group):
                                    hierarchy = {}
                                    hierarchy['table_schema'] = pdf_results.iloc[group.index[0]]['table_schema']
                                    hierarchy['table_name'] = pdf_results.iloc[group.index[0]]['table_name']
                                    hierarchy['table_description'] = pdf_results.iloc[group.index[0]]['table_description']
                                    hierarchy['columns'] = pdf_results.iloc[group.index[0]]['columns']
                                    return hierarchy
                                
                                # select table_schema, table_name, table_description, [column_name, column_descriptions] from the dataframe and turn into a hierarchical json
                                json_results = pdf_results.groupby(['table_schema', 'table_name', 'table_description']).value_counts().to_frame('Ct').reset_index().sort_values(by='Ct', ascending=False).drop_duplicates(subset=['table_schema', 'table_name', 'table_description']).reset_index().groupby(['table_schema', 'table_name', 'table_description']).apply(transform_group).to_json(orient='records')
                                # Maintain the history and show series of expanded results in reverse chrono order
                                assistant_output = md.empty()
                                descriptive_response = format_sql(sql_chain(question, json_results, path_to_save_chroma="./chroma_db", md_output=StreamlitMarkdownProgressHandler(assistant_output), stop=["```", "]]]"])['text'].rstrip(']]]').rstrip('```').lstrip('```').strip(), )
                                assistant_output.empty()
                                st.session_state.sqls.append(
                                    {"question": question, 'response': descriptive_response, 'column_results': pdf_results, 'time':time.time()})
                                    
                if st.session_state.sqls:
                    sql_assistant_container.header("SQL History", anchor="data-assistant")
                    for i, search in enumerate(st.session_state.sqls[-10:][::-1]):
                        with st.expander(f"""# {search["question"][:256] + ("..." if len(search["question"]) > 256 else "")}""", expanded=(i==0)):
                            st.dataframe(search["column_results"])
                            st.markdown(f'```sql\n{search["response"]}', unsafe_allow_html=True)
                    st.button("Clear history", on_click=clear_chat_history)

    
    st.sidebar.header("Actions", divider=True)
    status = st.sidebar.empty()
    reindex = st.sidebar.button("Reindex Catalog", key="Wipe and reindex")
    if reindex:
        if os.path.exists("./chroma_db"):
            shutil.rmtree("./chroma_db")
            create_vectorstore(st.session_state.dataset)
            status.success("Removed previous index", icon="✅") # delete icon

    with status:
        time.sleep(1)
        status.empty()

# Execute the main function
if __name__ == "__main__":
    show()    