from langchain_community.document_loaders import DataFrameLoader
from langchain.vectorstores import FAISS
from langchain.vectorstores import VectorStore
from langchain.embeddings import SentenceTransformerEmbeddings
from llama_index import PromptTemplate
from .llm_utils import get_llm, llm_decorator
import os
import pandas as pd

def create_vectorstore(path_to_save_chroma = './hts_db'):
    if not os.path.exists(path_to_save_chroma):
        hts_df = pd.read_csv('datasets/indexable_data.csv.gz', dtype=str, usecols=['HS8', 'Section', 'Chapter', 'Section_Summary', 'Chapter_Summary', 'Item_Summary'])
        pdf = hts_df[['HS8', 'Section', 'Chapter', 'Section_Summary', 'Chapter_Summary', 'Item_Summary']]
        load_data(pdf.fillna('').astype(str), path_to_save_chroma=path_to_save_chroma)

def load_data(pdf, path_to_save_chroma = './hts_db'):
    loader = DataFrameLoader(pdf, page_content_column="Item_Summary",)
    documents = loader.load()
    embedding_function = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")
    db = FAISS.from_documents(documents, embedding_function)
    db.save_local(path_to_save_chroma)
    return db

@llm_decorator()
def hts_chain(llm, query, path_to_save_chroma = './hts_db', **kwargs):
    from langchain.chains import RetrievalQA
    from langchain.vectorstores import Chroma
    from langchain.embeddings import SentenceTransformerEmbeddings
    from langchain_core.prompts import PromptTemplate
    vectordb = get_vectordb(path_to_save_chroma=path_to_save_chroma)
    prompt = PromptTemplate.from_template("""
You are a customs agent that is responsible for classifying goods for import and export.
Using the following pieces of retrieved context, categorize the goods described in the user query with ONE MOST relevant concise HS8 code.
If you don't know (or confident) the answer from the rerieved context, please respond with "I don't know".
Keep the response brief, and use the following reponse format:
'''Response: {{8 digit code}}. {{Brief explanation in 3 sentences or less for why the query is relevant to the HS8 code}} }}'''

User Query: {question}
Retrieved Context: {context}
Category: '''Response: """)
    genie = RetrievalQA.from_llm(llm=llm, prompt=prompt, retriever=vectordb.as_retriever(search_type="mmr", search_kwargs={"score_threshold": 0.6}))
    return genie(query)

def get_vectordb(path_to_save_chroma='./hts_db'):
    if not hasattr(get_vectordb, 'vectordb'):
        from langchain.vectorstores import FAISS
        from langchain.embeddings import SentenceTransformerEmbeddings
        embedding_function = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")
        get_vectordb.vectordb = FAISS.load_local(path_to_save_chroma, embedding_function)
    return get_vectordb.vectordb

def search_columns(query, path_to_save_chroma='./hts_db', k=5):
    vectordb = get_vectordb(path_to_save_chroma=path_to_save_chroma)
    return vectordb.max_marginal_relevance_search(query, k, fetch_k=k*5, lambda_mult=0.1)