import ast
from contextlib import contextmanager
from datetime import timedelta
import shutil
from sqlalchemy import create_engine
import streamlit as st
from sql_formatter.core import format_sql
import os, json, pandas as pd, time
from .catalog_utils import analyze_temporal_trend_arima, refresh_schema, dbname, get_catalog, update_table_columns, update_sample, update_table_description, update_column_description, get_stocks, get_temporal, get_dimensional, get_measures, analyze_temporal_trend
from .data_search_utils import create_vectorstore, search_columns, sql_chain, stories_chain, trends_chain
from .datalake_utils import execute_trino_query

def show():
    # Center align the header
    from .llm_utils import get_llm, StreamlitMarkdownProgressHandler

    st.markdown(f"<h1 style='text-align: center;'>Stories Assistant</h1>", unsafe_allow_html=True)
    st.header("", divider=True)
    st.subheader("Define Your Query")
    example_query = format_sql("""select a.*, b.sector, b.full_name from default.s_and_p_5_years a, (select distinct name full_name, sector, symbol from default.s_and_p_mapping) b where a.name = b.symbol""", )
    user_query = st.text_area("Enter SQL Query", value=example_query, height=160)

    if not hasattr(st.session_state, "datasets"):
        st.session_state.datasets = None
        st.session_state.temporal = None
        st.session_state.dimensional = []
        st.session_state.measures = []

    if st.button("Query"):
        if user_query:
            st.session_state.datasets = None
            with st.spinner("Loading..."):
                st.session_state.datasets = execute_trino_query(user_query).reset_index(drop=True)
                temporal_attribute = get_temporal(st.session_state.datasets)
                temporal_attribute = temporal_attribute.strip() if temporal_attribute else None
                dimensional_attributes = get_dimensional(st.session_state.datasets, temporal_attribute)
                measurements = get_measures(st.session_state.datasets, temporal_attribute, dimensional_attributes)
                st.session_state.temporal = temporal_attribute if temporal_attribute in st.session_state.datasets.columns else None
                st.session_state.dimensional = ast.literal_eval(dimensional_attributes)
                st.session_state.measures = ast.literal_eval(measurements)
                st.write(f"AI thinks that temporal attribute is {st.session_state.temporal}")
                st.write(f"AI thinks that dimensional attributes are {st.session_state.dimensional}")
                st.write(f"AI thinks that metric attributes are {st.session_state.measures}")
    
    # Function to plot the charts using Plotly
    import plotly.express as px

    def plot_temporal_charts(container, data, temporal_col, measure_col):
        # Filter data for the specific measure column
        # Create a line plot with Plotly
        fdata = data[data['Measure_Column'] == measure_col].groupby([temporal_col, 'Measure_Column', 'Dimensional_Series']).agg({'Actual': 'mean'}).reset_index()
        fig = px.bar(fdata, x=temporal_col, y='Actual', 
                    title=f"Temporal Chart for {measure_col}",
                    labels={'value': fdata['Dimensional_Series'], 'variable': 'Type'})

        # Display the plot in Streamlit
        container.plotly_chart(fig)
        
    if st.session_state.datasets is not None:
        st.sidebar.subheader("Metadata", divider=True)
        st.sidebar.markdown(f"**{len(st.session_state.datasets)}** attributes")
        st.sidebar.dataframe(st.session_state.datasets.describe(include='all'))
        
        stories_container = st.container()
        if hasattr(st.session_state, "datasets") and st.session_state.datasets is not None:
            st.write("Dataset")
            stories_container.dataframe(st.session_state.datasets, use_container_width=True)
        temp, meas, dim = stories_container.columns(3)
        if hasattr(st.session_state, "temporal") and st.session_state.temporal is not None:
            temp.write("Temporal")
            st.session_state.temporal = temp.text_input("Select Temporal Attribute", placeholder=st.session_state.temporal, value=st.session_state.temporal)
        if hasattr(st.session_state, "dimensional") and st.session_state.dimensional is not None:
            dim.write("Dimensional")
            st.session_state.dimensional = dim.multiselect("Select Dimensional Attributes", options=st.session_state.datasets.select_dtypes(exclude='number').columns, default=st.session_state.dimensional)
        if hasattr(st.session_state, "measures") and st.session_state.measures is not None:
            meas.write("Measures")
            st.session_state.measures = meas.multiselect("Select Measures", options=st.session_state.datasets.select_dtypes(include='number').columns, default=st.session_state.measures)
        if hasattr(st.session_state, "temporal") and st.session_state.temporal is not None and hasattr(st.session_state, 'datasets') and st.session_state.datasets is not None:
            df = st.session_state.datasets
            temporal_col = st.session_state.temporal
            start_date, cut_date = st.slider(
                "Select Historic Window",
                min_value=df[temporal_col].min(),
                max_value=df[temporal_col].max(),
                value=(df[temporal_col].min(), df[temporal_col].max() - timedelta(days=365))
            )
            end_date = df[temporal_col].max()
        with st.form("stories_assistant"):
            submit_button = st.form_submit_button(label='Analyze Emerging Trends', help="Click to analyze latest trends")
            if submit_button:
                md = stories_container.container()
                with st.spinner('Processing...'): #
                    temporal_col = st.session_state.temporal
                    
                    trends = analyze_temporal_trend(st.session_state.datasets.copy(), temporal_col, st.session_state.measures, cut_date, start_date, end_date, groupby_cols=st.session_state.dimensional)
                    stories_container.subheader("Emerging Trends", divider=True)
                    trendcol, trendstories = stories_container.columns(2)
                    trendcol.dataframe(trends, use_container_width=True)
                    story_output = trendstories.empty()
                    story_descriptive_response = trends_chain(trends['Percentage Change'], md_output=StreamlitMarkdownProgressHandler(story_output), stop=["```", "]]]"])
                    story_output.empty()
                    
                    arima_trends = analyze_temporal_trend_arima(st.session_state.datasets.copy(), temporal_col, st.session_state.measures, cut_date, start_date, end_date, groupby_cols=st.session_state.dimensional)
                    selected_rows = arima_trends[(arima_trends['Percentage Change'] >= 10) | (arima_trends['Percentage Change'] <= -10)].reset_index()
                    selected_rows[temporal_col] = pd.to_datetime(selected_rows[temporal_col]).dt.strftime('%Y-%m-%d')
                    selected_rows.set_index(['Dimensional_Series', 'Measure_Column', temporal_col])['Percentage Change'].sort_values(ascending=False).to_frame()
                    stories_df = pd.concat([selected_rows.head(10), selected_rows.tail(10)]).drop_duplicates()
                    stories_container.subheader("Seasonal Trends", divider=True)
                    datacol, storiescol = stories_container.columns(2)
                    datacol.dataframe(arima_trends, use_container_width=True)
                    assistant_output = storiescol.empty()
                    descriptive_response = stories_chain(stories_df, md_output=StreamlitMarkdownProgressHandler(assistant_output), stop=["```", "]]]"])
                    assistant_output.empty()
                    story_output.markdown(story_descriptive_response['text'].rstrip('```').lstrip('```').strip())
                    assistant_output.markdown(descriptive_response['text'].rstrip('```').lstrip('```').strip())

                    for measure in st.session_state.measures:
                        plot_temporal_charts(stories_container, arima_trends.copy().reset_index(), temporal_col, measure)

# Execute the main function
if __name__ == "__main__":
    show()    