import shutil
import streamlit as st
import os, json, pandas as pd, time
from .catalog_utils import refresh_schema, dbname, get_catalog, update_table_columns, update_sample, update_table_description, update_column_description
from .data_search_utils import create_vectorstore, search_columns, search_catalog_chain

def show():
    # Center align the header
    from .llm_utils import get_llm, StreamlitMarkdownProgressHandler

    st.markdown(f"<h1 style='text-align: center;'>Catalog Search</h1>", unsafe_allow_html=True)
    st.header("", divider=True)
    if not hasattr(st.session_state, "dataset"):
        st.session_state.dataset = None

    with st.spinner("Loading..."):
        st.session_state.dataset = get_catalog()
        create_vectorstore(st.session_state.dataset)

    if st.session_state.dataset is not None:
        st.sidebar.subheader("Metadata", divider=True)
        st.sidebar.markdown(f"**{len(st.session_state.dataset)}** attributes found in the catalog")
        st.sidebar.dataframe(st.session_state.dataset[['table_schema', 'table_name', 'column_name', 'table_hash']].describe(include='all'))


    def clear_chat_history():
        st.session_state.searches = []

    if "searches" not in st.session_state:
        st.session_state.searches = []

    catalog_assistant = st.container()
    if os.path.exists('chroma_db'):
        with catalog_assistant:
            with st.form("catalog_search"):
                question = st.text_input("Find your data here...", value="Average price of technology stocks in 2017", help="Enter a natural language query to locate relevant data attributes in the datalake")
                submit_button = st.form_submit_button(label='Locate', help="Click to search")
                if submit_button:
                    md = catalog_assistant.container()
                    with md:
                        if question:
                            with st.spinner('Processing...'): #
                                table_results = search_columns(question, k=10)
                                if table_results:
                                    pdf_results = pd.DataFrame.from_dict([result.metadata for result in table_results])[['table_schema', 'table_name', 'column_name', 'table_description', 'column_description', 'sample_values']].set_index(['table_schema', 'table_name', 'column_name', 'table_description', 'column_description'])
                                else:
                                    pdf_results = pd.DataFrame()
                                # Maintain the history and show series of expanded results in reverse chrono order
                                assistant_output = st.empty()
                                descriptive_response = search_catalog_chain(question, md_output=StreamlitMarkdownProgressHandler(assistant_output), stop=["```", "]]]"])['result']
                                assistant_output.empty()
                                st.session_state.searches.append(
                                    {"question": question, 'response': descriptive_response, 'column_results': pdf_results, 'time':time.time()})
                                
            if st.session_state.searches:
                catalog_assistant.header("Search History", anchor="data-assistant")
                for i, search in enumerate(st.session_state.searches[-10:][::-1]):
                    with st.expander(f"""# {search["question"][:256] + ("..." if len(search["question"]) > 256 else "")}""", expanded=(i==0)):
                        st.markdown(f"""{search["response"]}""", unsafe_allow_html=True)
                        st.dataframe(search["column_results"])
                st.button("Clear history", on_click=clear_chat_history)

    
    st.sidebar.header("Actions", divider=True)
    col1, space = st.sidebar.columns([1, 9])
    status = st.sidebar.empty()
    with col1:
        reindex = st.sidebar.button("Reindex Catalog", key="Wipe and reindex")
        if reindex:
            if os.path.exists("./chroma_db"):
                shutil.rmtree("./chroma_db")
                create_vectorstore(st.session_state.dataset)
                status.success("Removed previous index", icon="✅") # delete icon

    with status:
        time.sleep(1)
        status.empty()
# Execute the main function
if __name__ == "__main__":
    show()    