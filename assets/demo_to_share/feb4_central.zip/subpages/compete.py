from contextlib import contextmanager
from io import BytesIO
import pickle
import shutil
import streamlit as st
from sql_formatter.core import format_sql
import os, json, pandas as pd, time
import feedparser

from langchain_community.document_loaders import DataFrameLoader
from langchain.vectorstores import FAISS
from langchain.vectorstores import VectorStore
from langchain.embeddings import SentenceTransformerEmbeddings
import urllib

from .llm_utils import llm_decorator, StreamlitMarkdownProgressHandler
from .all_things_consts import css_code, microphone_code, script_code

file_dir = 'uploads'

def index_documents(documents, path_to_save_chroma = './chroma_db'):
    embedding_function = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")
    db = FAISS.from_documents(documents, embedding_function)
    db.save_local(path_to_save_chroma)
    return db

def index_urls(urls, directory, filename, overwrite=False):
    if not os.path.exists(directory):
        os.makedirs(directory)
    idx_path = os.path.join(directory, filename)
    if overwrite and os.path.exists(idx_path):
        shutil.rmtree(idx_path)
    if not os.path.exists(idx_path):
        docs = WebBaseLoader(urls).load()
        index_documents(docs, idx_path)
        pickle.dump(docs, open(f'{idx_path}/docs.pkl', 'wb'))
    return idx_path

def read_index(idx_path):
    if not hasattr(read_index, f'vectordb_{idx_path}'):
        from langchain.vectorstores import FAISS
        from langchain.embeddings import SentenceTransformerEmbeddings
        embedding_function = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")
        setattr(read_index, f'vectordb_{idx_path}', FAISS.load_local(idx_path, embedding_function))
    return getattr(read_index, f'vectordb_{idx_path}')

def read_docs(idx_path):
    if not hasattr(read_docs, f'docs_{idx_path}'):
        setattr(read_docs, f'docs_{idx_path}', pickle.load(open(f'{idx_path}/docs.pkl', 'rb')))
    return getattr(read_docs, f'docs_{idx_path}')

from langchain.chains import AnalyzeDocumentChain, RetrievalQA
from langchain.document_loaders import WebBaseLoader
from langchain.chains.question_answering import load_qa_chain

@llm_decorator()
def get_web_answer(llm, question, **kwargs):
    from langchain.chains.combine_documents.stuff import StuffDocumentsChain
    from langchain.chains import ConversationChain
    from langchain_core.prompts import PromptTemplate
    from langchain.memory import ConversationSummaryMemory, ChatMessageHistory
    if not hasattr(st.session_state, 'web_index_name') or not st.session_state.web_index_name:
        # Open ini file and read in the index name
        if os.path.exists('rindex.ini'):
            with open('rindex.ini', 'r') as f:
                idx_path = f.read()
                idx_path = idx_path.split('=')[1]
                st.session_state.rss_index_name = idx_path
        else:
            st.session_state.web_index_name = None
    if os.path.exists('uploads') and st.session_state.rss_index_name is not None:
        idx_path = st.session_state.rss_index_name
        vector_index = read_index(idx_path)
        retriever = vector_index.as_retriever(k=3)
        if not hasattr(st.session_state, "compete_memory") or st.session_state.compete_memory is None:
            st.session_state.compete_memory = ConversationSummaryMemory(llm=llm, memory_size=5, input_key='question', output_key='result')
        if not hasattr(st.session_state, "compete_llm") or st.session_state.compete_llm is None:
            st.session_state.compete_llm = RetrievalQA.from_llm(llm=llm, prompt=PromptTemplate.from_template("""Please answer the user's question based on the retrieved context (and retrieved context only). If you cannot answer the question from the context, please respond that you do not know.
Context: ```{context}```
Question: `{question}`
Answer:```
"""), verbose=True, retriever=retriever)
        resp = st.session_state.compete_llm(question)
        return (resp['result'], "") if question else ("Please enter a valid question", "")
    else:
        return ("Please upload a file to answer questions", "")
    

@llm_decorator()
def summarize(llm, **kwargs):
    from langchain.chains.combine_documents.stuff import StuffDocumentsChain
    from langchain.chains import ConversationChain
    from langchain_core.prompts import PromptTemplate
    from langchain.memory import ConversationSummaryMemory, ChatMessageHistory
    from langchain.chains import MapReduceDocumentsChain, ReduceDocumentsChain
    from langchain.text_splitter import CharacterTextSplitter
    if not hasattr(st.session_state, 'web_index_name') or not st.session_state.web_index_name:
        # Open ini file and read in the index name
        if os.path.exists('rindex.ini'):
            with open('rindex.ini', 'r') as f:
                idx_path = f.read()
                idx_path = idx_path.split('=')[1]
                st.session_state.rss_index_name = idx_path
        else:
            st.session_state.web_index_name = None
    if os.path.exists('uploads') and st.session_state.rss_index_name is not None:
        idx_path = st.session_state.rss_index_name
        vector_index = read_index(idx_path)
        docs = read_docs(idx_path)
        from langchain.chains import LLMChain

        map_template = """The following is a document. Please summarize it in 2 sentences or less. No more than 100 words.
        {docs}
        Helpful Answer: ```"""
        map_prompt = PromptTemplate.from_template(map_template)
        map_chain = LLMChain(llm=llm, prompt=map_prompt)
        if not hasattr(st.session_state, "compete_chain") or st.session_state.compete_chain is None:
            st.session_state.compete_chain = map_chain

        text_splitter = CharacterTextSplitter.from_tiktoken_encoder(
            chunk_size=1000, chunk_overlap=0
        )
        split_docs = text_splitter.split_documents(docs)
        def summarize_doc(doc):
            try:
                return st.session_state.compete_chain.run(doc)
            except:
                return ""
        newline = "\n"
        resp = f"""Summary:{newline}{newline.join(['- ' + summarize_doc(doc).strip().rstrip('```').rstrip(']]]').strip() for doc in split_docs if summarize_doc(doc)])}"""
        return resp
    else:
        return "Error occurred"

# Create a function to return md5 name for the file name
def get_filename_md5(filename):
    import hashlib
    md5 = hashlib.md5()
    md5.update(filename.encode('utf-8'))
    return md5.hexdigest()

def show():
    st.markdown(css_code, unsafe_allow_html=True)
    # st.markdown(script_code, unsafe_allow_html=True)
    # Center align the header
    from .llm_utils import get_llm, StreamlitMarkdownProgressHandler

    st.markdown(f"<h1 style='text-align: center;'>Staying Informed</h1>", unsafe_allow_html=True)
    st.header("", divider=True)
    if not hasattr(st.session_state, "competition"):
        st.session_state.competition = []

    st.sidebar.header("Memory", divider=True)
    # Create a button to wipe the memory and chat history
    if st.sidebar.button("Wipe Memory"):
        if hasattr(st.session_state, "compete_memory"):
            st.session_state.compete_memory.clear()
        if hasattr(st.session_state, "compete_llm"):
            st.session_state.comepete_llm = None
        if hasattr(st.session_state, "competition"):
            st.session_state.competition = []

    web_assistant = st.container()
    with web_assistant:
        urls, btn = web_assistant.columns([8, 1])
        rss_feed = urls.text_input("Enter the RSS Feed URL", value="https://www.google.com/alerts/feeds/02405105525787668759/7868272489342440970", help="Enter the RSS Feed URL here.", key="feeds")
        if btn.button("Refresh Feed", help="Refresh"):
            feed = feedparser.parse(rss_feed)
            pdf = pd.DataFrame(feed.entries)
            web_assistant.dataframe(pdf)
            from urllib.parse import urlparse, parse_qs
            pdf['url'] = pdf['links'].apply(lambda x: x[0]['href']).apply(lambda x: parse_qs(urlparse(x).query)['url'][0])
            wurls = list(sorted(list(set(pdf['url'].tolist()))))
            idx_name = get_filename_md5(str(wurls))
            web_prog = web_assistant.progress(0, "Retrieving URLs...")
            web_prog.progress(30, f"Indexing {idx_name}")
            idx_path = index_urls(wurls, file_dir, idx_name)
            web_prog.progress(60, f"Indexed {idx_path}")
            # Save this path so it can be used later in a ini file if needed
            with open('rindex.ini', 'w') as f:
                f.write(f"[index]\npath={idx_path}")
            if not hasattr(st.session_state, 'rss_index_name'):
                st.session_state.rss_index_name = None
            st.session_state.rss_index_name = None
            web_prog.progress(90, "Resetting index")
            if hasattr(st.session_state, "compete_memory"):
                st.session_state.compete_memory.clear()
            if hasattr(st.session_state, "compete_llm"):
                st.session_state.compete_llm = None
            web_prog.progress(100, "Done")
            time.sleep(1)
            web_prog.empty()

        console_output = web_assistant.empty()
        if web_assistant.button("Summarize"):
            with st.spinner('Processing...'):
                web_assistant_output = web_assistant.empty()
                if not hasattr(st.session_state, 'r_summary') or not st.session_state.r_summary:
                    st.session_state.r_summary = None
                st.session_state.r_summary = summarize(md_output=StreamlitMarkdownProgressHandler(web_assistant_output), stop=["```", "]]]"], timeout=120)
                web_assistant_output.empty()
                
        if hasattr(st.session_state, 'r_summary') and st.session_state.r_summary:
            console_output.write(st.session_state.r_summary.strip().rstrip('```').rstrip(']]]').strip())

            web_assistant.subheader("Ask a Question", anchor="webpage-assistant", divider=True)
            col1, col2 = web_assistant.columns([10, 1])
            web_question = col1.text_input("What do you seek?", value="What is IBM's SNAP Program?", help="Enter your question here.", key="web_question")
            web_submit_button = col2.button(label='Answer', help="Answer my question", type="primary")
            md_web = web_assistant.container()
            if web_submit_button:
                if web_question:
                    with st.spinner('Processing...'):
                        web_assistant_output = md_web.empty()
                        web_descriptive_response, web_sources = get_web_answer(web_question, md_output=StreamlitMarkdownProgressHandler(web_assistant_output), stop=["```", "]]]"])
                        web_descriptive_response = web_descriptive_response.strip().rstrip("```").rstrip("]]]").strip()
                        web_assistant_output.empty()
                        newline = "\n"
                        web_assistant_output.markdown(f"""{web_descriptive_response} <br>{str(web_sources)}""", unsafe_allow_html=True)
                        st.session_state.competition.append({"question": web_question, 'response': web_descriptive_response, 'type':'webpage', 'time':time.time()})

    if hasattr(st.session_state, 'competition') and st.session_state.competition:
        history = st.container()
        history.subheader("History", anchor="historycompete-assistant", divider=True)
        for i, search in enumerate(st.session_state.competition[-10:][::-1]):
            with st.expander(f""" *{len(st.session_state.competition) - i}*. *{search["question"][:96] + ("..." if len(search["question"]) > 96 else "")}*""", expanded=(i==0)):
                qno, answercol = st.columns([3, 9])
                qno.markdown(f"""<h1 style='text-align: left;'>{len(st.session_state.competition) - i}<sub>{search['type']}</sub></h1>
<i><strong>{search["question"]}</strong></i>""", unsafe_allow_html=True)
                answercol.markdown(f"""<p style='text-align: left; font-style: italic;'>{search["response"]}</p>""", unsafe_allow_html=True)                                    

# Execute the main function
if __name__ == "__main__":
    show()