import pandas as pd
hts = pd.read_csv(r'C:\Users\edala\Downloads\indexable_data (3).csv\indexable_data.csv', dtype=str, usecols=['HS8', 'Item_Summary'])
hts.columns = ['HS8', 'Text']
hts.to_csv('hts.csv', index=False)
print(hts.head())