import streamlit as st

css_code = """<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">"""
script_code = """
<script type="text/javascript">
document.getElementById("microphone").addEventListener("click", function() {
    console.log("Listening...")
    var recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition || window.mozSpeechRecognition || window.msSpeechRecognition)();
    recognition.continuous = true;
    recognition.lang = 'en-US';
    
    recognition.onstart = function() {
        // Display a message when listening starts
        var message = document.createElement("p");
        message.textContent = "Listening...";
        document.body.appendChild(message);
    };

    recognition.onresult = function(event) {
        var result = event.results[event.resultIndex];
        var text = result[0].transcript;
        document.getElementById("question").value = text;
    };

    recognition.start();
});
</script>
"""

microphone_code = """
<style>
.microphone {
    cursor: pointer;
};
</style>
<i class="fas fa-microphone microphone" id="microphone"></i>
"""