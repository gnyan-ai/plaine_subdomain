from langchain_community.document_loaders import DataFrameLoader
from langchain.vectorstores import FAISS
from langchain.vectorstores import VectorStore
from langchain.embeddings import SentenceTransformerEmbeddings
from llama_index import PromptTemplate
from .llm_utils import get_llm, llm_decorator
import os

def create_vectorstore(pdf, path_to_save_chroma = './chroma_db'):
    if not os.path.exists(path_to_save_chroma):
        pdf['text'] = pdf['table_description'].fillna('').astype(str) + ' ' + pdf['column_description'].fillna('').astype(str) + ' ' + pdf['sample_values'].fillna('').astype(str)
        load_data(pdf.fillna('').astype(str), path_to_save_chroma=path_to_save_chroma)

def load_data(pdf, path_to_save_chroma = './chroma_db'):
    loader = DataFrameLoader(pdf, page_content_column="text",)
    documents = loader.load()
    embedding_function = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")
    db = FAISS.from_documents(documents, embedding_function)
    db.save_local(path_to_save_chroma)
    return db

@llm_decorator()
def search_catalog_chain(llm, query, path_to_save_chroma = './chroma_db', **kwargs):
    from langchain.chains import RetrievalQA
    from langchain.vectorstores import Chroma
    from langchain.embeddings import SentenceTransformerEmbeddings
    from langchain_core.prompts import PromptTemplate
    vectordb = get_vectordb(path_to_save_chroma=path_to_save_chroma)
    prompt = PromptTemplate.from_template("""You are an EXPERT master data librarian that catalogs and acts as a *SME* for the data repository.
You will receive a query from a user and table information of the warehouse in the retrieved context: from those, you you will dutifully explore the retrieved context (comprising of a table_schema, table_name, column_name, column_description, table_description) and return the most relevant columns/attributes, preferably from the same table or a coherent set of relational tables, that can best relate/answer the user's query.
You are allowed to creatively infer and find any extended interpretations of the context to answer the customer query. However, you are NOT allowed to fabricate or presume any attributes that are NOT already present in the context. 
If you do not have sufficient information to answer the query, you can respond with "Do not have sufficient information for guided search".
Be VERY brief. 
Your response MUST be less than 100 words, preferably in a single sentence which presents both table and column information as an itemized list.
YOU MUST END YOUR RESPONSE with a ]]] (triple right brackets) to signify the end of your response. Always enclose table names and column names in backticks.
User Query: {question}
Table Info: {context}
Answer: ```""")
    genie = RetrievalQA.from_llm(llm=llm, prompt=prompt, retriever=vectordb.as_retriever(search_type="mmr", search_kwargs={"score_threshold": 0.6}))
    return genie(query)

@llm_decorator()
def stories_chain(llm, query, **kwargs):
    from langchain.chains import LLMChain, create_sql_query_chain, RetrievalQA
    from langchain.vectorstores import Chroma
    from langchain.embeddings import SentenceTransformerEmbeddings
    from langchain_core.prompts import PromptTemplate
    from langchain_community.utilities import SQLDatabase
    prompt = PromptTemplate.from_template("""I will give you a dataframe (in JSON format) that compares latest performance with prior historic performance: you will see 10 leading rows and 10 lagging rows of the dataframe.
You must generate a narrative of your observations from the dataframe in 10 bulleted sentences or less in markdown format enclosed in ``` backticks. Each sentence must represent an observation. Think step by step and be brief. 
You are helping business analysts to spot any anomalies and outlier observations in the data.
You are ONLY allowed to present objective facts; not subjective opinions.
You are allowed to skip short if you do not have any observations to report.
You MUST ALWAYS include a reference to that period in your observation. You are penalized if you do not include a reference to the period.
You are NOT allowed to use abstract anaphoric references like "this period", "previous year" etc. Instead, use absolutes "Q1 2021", "August 2017" etc.
When citing numeric values, use decimals to the nearest 2 decimal places. Similarly use US notations for currency, percentages, dates, and large numbers.
Dataframe: ```{context}```
Narrative: ```markdown
""")
    genie = LLMChain(llm=llm, prompt=prompt,)
    return genie.invoke({'context':query.reset_index().to_json(orient='records')})

@llm_decorator()
def trends_chain(llm, query, **kwargs):
    from langchain.chains import LLMChain, create_sql_query_chain, RetrievalQA
    from langchain.vectorstores import Chroma
    from langchain.embeddings import SentenceTransformerEmbeddings
    from langchain_core.prompts import PromptTemplate
    from langchain_community.utilities import SQLDatabase
    prompt = PromptTemplate.from_template("""I will give you a dataframe (in JSON format) that compares latest performance compared with prior historic performance. All metric values are reported separately and presented in the dataframe as percentages ONLY. Do not interpret any relationship between the metrics.
You must generate a narrative of your observations from the dataframe in 10 bulleted sentences or less in markdown format enclosed in ``` backticks. Each sentence must represent an observation. Think step by step and be brief. 
You are helping business analysts to spot any anomalies and outlier observations in the data.
You are ONLY allowed to present objective facts; not subjective opinions.
You are allowed to skip short if you do not have any observations to report.
When citing numeric values, use decimals to the nearest 2 decimal places. Similarly use US notations for currency, percentages, dates, and large numbers.
Dataframe: ```{context}```
Narrative: ```markdown
""")
    genie = LLMChain(llm=llm, prompt=prompt,)
    return genie.invoke({'context':query.reset_index().to_json(orient='records')})
                                          
@llm_decorator()
def sql_chain(llm, query, context, path_to_save_chroma, **kwargs):
    from langchain.chains import LLMChain, create_sql_query_chain, RetrievalQA
    from langchain.vectorstores import Chroma
    from langchain.embeddings import SentenceTransformerEmbeddings
    from langchain_core.prompts import PromptTemplate
    from langchain_community.utilities import SQLDatabase
    vectordb = get_vectordb(path_to_save_chroma=path_to_save_chroma)
    prompt = PromptTemplate.from_template("""You are an EXPERT Hive SQL analyst that can author good Hive SQL to answer the question.
You are presented with a user query. You will have the table info (schemas, tables, columns, and sample attributes) in the context.
DO NOT LOOK BEYOND THE CONTEXT to answer the user query. 

For an example query: "what is the id and full name of the customer whose first name is John?", a good response shall be:
```sql
WITH step_1 AS (SELECT `customer_id`, `customer_name` FROM `default`.`customer` WHERE `customer_name` LIKE 'John%') 
SELECT * FROM step_1 LIMIT 1;
```

To accomplish your task, please think step-by-step --
 - First, decompose a user's complex query into "simple" steps.
 - Second, order steps in a logical sequence.
 - Third, for each step, author a `SELECT` SQL clause as a `WITH` CTE to be used in a subsequent step.
 - Fourth, at each step, evaluate that each clause is syntactically correct Hive SQL (OTHER DIALECTS ARE NOT ALLOWED).
 - Fifth, slot the filter, group, join, projection clauses into the CTE clause correctly.
 - Sixth, revisit the prior steps and current step to verify the semantic and syntax integrity. Rules are presented below.
 - Finally, as the final step, assemble a full SQL response by combining prior CTE clauses in the correct order.
 - You are rewarded for short SQL responses.

These rules MUST be followed at all times:
 1) Generate SQL response in Hive SQL dialect.
 2) Quote all schemas, columns and the table references in ` backticks. 
 3) You will only create SELECT (read-only) SQL statements. You will NOT create any INSERT/UPDATE/DELETE SQL statements.
 4) Don't presume or imply any additional columns and tables beyond those presented in the table info.
 5) If you don't have sufficient information to build a clause, you can choose respond with `SELECT '1'` as a placeholder CTE clause at any step.
 6) DO NOT USE complex SQL constructs such as 'NATURAL JOIN`, `CROSS JOIN`, `LATERAL VIEW`, `EXPLODE`, `WINDOW/OVER` and other complex SQL constructs UNLESS ABSOLUTELY NECESSARY.
 7) ALWAYS VERIFY the participant columns & tables are present in the table info.
 8) Avoid comments in your SQL.
 9) Always use fully-qualified table names (i.e. `table_name`.`column_name` or `cte_alias` or `column_alias`).
 10) Generate a SINGLE SQL RESPONSE ONLY, preferably in a single line. Please DO NOT include any other text in your response.
Query: {question}
Table Info: {context}
Answer: ```sql
""")

    chain_type_kwargs = {"prompt": prompt}
    genie = LLMChain(llm=llm, prompt=prompt,)
    vectordb = get_vectordb(path_to_save_chroma=path_to_save_chroma)
    #genie = RetrievalQA.from_llm(llm=llm, prompt=prompt,retriever=vectordb.as_retriever(search_kwargs={"k": 10, "score_threshold": 0.5}))
    return genie.invoke({'question':query, 'context':context})

def get_vectordb(path_to_save_chroma='./chroma_db'):
    if not hasattr(get_vectordb, 'vectordb'):
        from langchain.vectorstores import FAISS
        from langchain.embeddings import SentenceTransformerEmbeddings
        embedding_function = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")
        get_vectordb.vectordb = FAISS.load_local(path_to_save_chroma, embedding_function)
    return get_vectordb.vectordb

def search_columns(query, path_to_save_chroma='./chroma_db', k=5):
    vectordb = get_vectordb(path_to_save_chroma=path_to_save_chroma)
    return vectordb.similarity_search(query, k, ) #max_marginal_relevance_search(query, k, fetch_k=k*2) 