import shutil
import streamlit as st
import os, json, pandas as pd, time
from .cbp_utils import create_vectorstore, hts_chain, search_columns

def show():
    # Center align the header
    from .llm_utils import get_llm, StreamlitMarkdownProgressHandler

    st.markdown(f"<h1 style='text-align: center;'>Cargo Customs Agent</h1>", unsafe_allow_html=True)
    st.header("", divider=True)

    with st.spinner("Loading..."):
        create_vectorstore()

    st.sidebar.subheader("Metadata", divider=True)
    st.sidebar.markdown(f"Trusted Cargo Classification System")

    def clear_chat_history():
        st.session_state.hts = []

    if "hts" not in st.session_state:
        st.session_state.hts = []

    cargo_assistant = st.container()
    if os.path.exists('hts_db'):
        with cargo_assistant:
            with st.form("hts_search"):
                question = st.text_input("Harmonized Tariff Schedule", value="अदरक and लहसुन", placeholder="Enter a description of the goods", help="Enter a cargo description to classify a HTS code")
                submit_button = st.form_submit_button(label='Categorize', help="Click to categorize")
                if submit_button:
                    md = cargo_assistant.container()
                    with md:
                        if question:
                            with st.spinner('Processing...'): #
                                table_results = search_columns(question, k=3)
                                if table_results:
                                    pdf_results = pd.DataFrame.from_dict([result.metadata for result in table_results])[['HS8', 'Section', 'Chapter', 'Section_Summary', 'Chapter_Summary']]
                                else:
                                    pdf_results = pd.DataFrame()
                                # Maintain the history and show series of expanded results in reverse chrono order
                                assistant_output = md.empty()
                                descriptive_response = hts_chain(question, md_output=StreamlitMarkdownProgressHandler(assistant_output), stop=["```", "]]]"])['result'].strip().rstrip(']]]').rstrip('```').lstrip('```').strip()
                                #assistant_output.empty()
                                st.session_state.hts.append(
                                    {"question": question, 'response': descriptive_response, 'column_results': pdf_results, 'time':time.time()})
                                
            if st.session_state.hts:
                cargo_assistant.header("Cargo History", anchor="cargo-assistant")
                for i, search in enumerate(st.session_state.hts[-10:][::-1]):
                    with st.expander(f"""# {search["question"][:256] + ("..." if len(search["question"]) > 256 else "")}""", expanded=(i==0)):
                        st.markdown(f"""<strong>{search["response"]}</strong>""", unsafe_allow_html=True)
                        st.subheader("Using Search", divider=True)
                        st.dataframe(search["column_results"])
                st.button("Clear history", on_click=clear_chat_history)

# Execute the main function
if __name__ == "__main__":
    show()    