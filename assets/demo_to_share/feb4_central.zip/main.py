import os
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
import streamlit as st
from subpages import catalog, search_catalog, sql_assistant, all_cbp, all_things, stories_assistant #, search, trends, reports, competition, pulse, sharepoint, code, cloud
from streamlit_card import card
from datetime import datetime
from utils.utils import image_data, hide_footer, update_ollama_status
hide_footer()
update_ollama_status()

if not hasattr(st.session_state, "page"):
    st.session_state.page = "Home"

def navigate(page):
    st.session_state.page = page
    st.rerun()

def show():
    if st.session_state.page == "Home":
        # Center align the header
        st.markdown("<h1 style='text-align: center;'>AI Assistant Central</h1>", unsafe_allow_html=True)
        st.header("", divider=True)
        column_1, column_2, column_3 = st.columns(3)
        with column_1:
            card(
                title="Steward Assistant",
                text="Annotate your lakehouse with AI",
                image=image_data("images/catalog.jpg"),
                on_click=lambda: navigate("Catalog"),
                key='card1',
                styles={
                        "card": {
                        "width": "100%",
                        "height": "350px",
                        "border-radius": "20px",
                        "box-shadow": "0 0 10px rgba(200,200,200,0.5)",
                    },
                    "filter": {
                        "background-color": "rgba(0, 0, 0, 0.5)"
                    }
                }
            )
        with column_2:
            card(
                title="Search Assistant",
                text="Locate your data with ease",
                image=image_data("images/search.jpg"),
                on_click=lambda: navigate("Search"),
                key='card2',
                styles={
                        "card": {
                        "width": "100%",
                        "height": "350px",
                        "border-radius": "20px",
                        "box-shadow": "0 0 10px rgba(200,200,200,0.5)",
                    },
                    "filter": {
                        "background-color": "rgba(0, 0, 0, 0.5)"
                    }
                }
            )
        with column_3:
            card(
                title="Trends Assistant",
                text="Monitor your business with AI",
                image=image_data("images/trends.jpg"),
                on_click=lambda: navigate("Stories"),
                key='card3',
                styles={
                        "card": {
                        "width": "100%",
                        "height": "350px",
                        "border-radius": "20px",
                        "box-shadow": "0 0 10px rgba(200,200,200,0.5)",
                    },
                    "filter": {
                        "background-color": "rgba(0, 0, 0, 0.5)"
                    }
                }
            )

        column_4, column_5, column_6 = st.columns(3)
        with column_4:
            card(
                title="Reports Assistant",
                text="Self service report automation with AI",
                image=image_data("images/reports.jpg"),
                on_click=lambda: navigate("SQL"),
                key='card4',
                styles={
                        "card": {
                        "width": "100%",
                        "height": "350px",
                        "border-radius": "20px",
                        "box-shadow": "0 0 10px rgba(200,200,200,0.5)",
                    },
                    "filter": {
                        "background-color": "rgba(0, 0, 0, 0.5)"
                    }
                }
            )
        with column_5:
            card(
                title="Cohort Assistant",
                text="All things AI...",
                image=image_data("images/process.png"),
                on_click=lambda: navigate("All"),
                key='card5',
                styles={
                        "card": {
                        "width": "100%",
                        "height": "350px",
                        "border-radius": "20px",
                        "box-shadow": "0 0 10px rgba(200,200,200,0.5)",
                    },
                    "filter": {
                        "background-color": "rgba(0, 0, 0, 0.5)"
                    }
                }
            )
        with column_6:
            card(
                title="Pulse Assistant",
                text="Keep your pulse on the customer",
                image=image_data("images/pulse.jpg"),
                on_click=lambda: column_6.write(f"Hello from the card 3! {datetime.now()}"),
                key='card6',
                styles={
                        "card": {
                        "width": "100%",
                        "height": "350px",
                        "border-radius": "20px",
                        "box-shadow": "0 0 10px rgba(200,200,200,0.5)",
                    },
                    "filter": {
                        "background-color": "rgba(0, 0, 0, 0.5)"
                    }
                }
            )

        column_7, column_8, column_9 = st.columns([1,1,1])
        with column_7:
            card(
                title="HTS Assistant",
                text="Customs Cargo Coding Assistant",
                image=image_data("images/sharepoint.jpg"),
                on_click=lambda: navigate("HTS"),
                key='card7',
                styles={
                        "card": {
                            "width": "100%",
                            "height": "350px",
                            "border-radius": "20px",
                            "box-shadow": "0 0 10px rgba(200,200,200,0.5)",
                        },
                        "filter": {
                            "background-color": "rgba(0, 0, 0, 0.5)"
                        }
                }
            )
        with column_8:
            card(
                title="Coding Assistant",
                text="From text to code in minutes...",
                image=image_data("images/code.jpg"),
                on_click=lambda: column_8.write(f"Hello from the card 2! {datetime.now()}"),
                key='card8',
                styles={
                        "card": {
                        "width": "100%",
                        "height": "350px",
                        "border-radius": "20px",
                        "box-shadow": "0 0 10px rgba(200,200,200,0.5)",
                    },
                    "filter": {
                        "background-color": "rgba(0, 0, 0, 0.5)"
                    }
                }
            )
        with column_9:
            card(
                title="Cloud Assistant",
                text="From code to cloud in minutes...",
                image=image_data("images/cloud.jpg"),
                on_click=lambda: column_9.write(f"Hello from the card 3! {datetime.now()}"),
                key='card9',
                styles={
                        "card": {
                        "width": "100%",
                        "height": "350px",
                        "border-radius": "20px",
                        "box-shadow": "0 0 10px rgba(200,200,200,0.5)",
                    },
                    "filter": {
                        "background-color": "rgba(0, 0, 0, 0.5)"
                    }
                }
            )
        column_10, column_11 = st.columns(2)
        with column_10:
            card(
                title="Competitive Analyst",
                text="Industry news and competitive intelligence...",
                image=image_data("images/sharepoint.jpg"),
                on_click=lambda: navigate("Competitive"),
                key='card10',
                styles={
                        "card": {
                            "width": "100%",
                            "height": "350px",
                            "border-radius": "20px",
                            "box-shadow": "0 0 10px rgba(200,200,200,0.5)",
                        },
                        "filter": {
                            "background-color": "rgba(0, 0, 0, 0.5)"
                        }
                }
            )
        with column_11:
            card(
                title="Well being Assistant",
                text="Better health and wellness...",
                image=image_data("images/yoga.jpg"),
                on_click=lambda: column_11.write(f"Let's get better {datetime.now()}"),
                key='card11',
                styles={
                        "card": {
                        "width": "100%",
                        "height": "350px",
                        "border-radius": "20px",
                        "box-shadow": "0 0 10px rgba(200,200,200,0.5)",
                    },
                    "filter": {
                        "background-color": "rgba(0, 0, 0, 0.5)"
                    }
                }
            )
    
if st.session_state.page == "Catalog":
    catalog.show()
elif st.session_state.page == "SQL":
    sql_assistant.show()
elif st.session_state.page == "Search":
    search_catalog.show()
elif st.session_state.page == "HTS":
    all_cbp.show()
elif st.session_state.page == "All":
    all_things.show()
elif st.session_state.page == "Stories":
    stories_assistant.show()

if st.session_state.page != "Home":
    st.sidebar.markdown('---')
    if st.sidebar.button("⬅️ Back to Home", type="secondary"):
        st.session_state.page = "Home"
        st.rerun()

# Execute the main function
if __name__ == "__main__":
    show()