import os
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
from utils import image_data, hide_footer, update_ollama_status
hide_footer()
import streamlit as st
from subpages import catalog_assistant, search_assistant, hts_assistant, coding_assistant, extraction_assistant, powerpoint_assistant
from streamlit_card import card
from datetime import datetime
import pandas as pd

if not hasattr(st.session_state, "page"):
    st.session_state.page = st.query_params.to_dict().get('page', "Home")

def navigate(page):
    if st.session_state.page != page:
        st.session_state.page = page
        st.rerun()

def show():
    if st.session_state.page == "Home":
        # Center align the header
        st.markdown("<h1 style='text-align: center; font-size: 4em;'>AI Central</h1>", unsafe_allow_html=True)
        column_1, column_2, column_3 = st.columns([1, 1, 1])
        with column_1:
            card(
                title="Cataloging Assistant",
                text="Annotate your lakehouse with AI",
                image=image_data("images/catalog.jpg"),
                on_click=lambda: navigate("Catalog"),
                key='card1',
                styles={
                        "card": {
                        "width": "100%",
                        "height": "350px",
                        "border-radius": "20px",
                        "box-shadow": "0 0 10px rgba(200,200,200,0.5)",
                    },
                    "filter": {
                        "background-color": "rgba(0, 0, 0, 0.5)"
                    }
                }
            )
        with column_2:
            card(
                title="Search Assistant",
                text="Locate your data with ease",
                image=image_data("images/search.jpg"),
                on_click=lambda: navigate("Search"),
                key='card2',
                styles={
                        "card": {
                        "width": "100%",
                        "height": "350px",
                        "border-radius": "20px",
                        "box-shadow": "0 0 10px rgba(200,200,200,0.5)",
                    },
                    "filter": {
                        "background-color": "rgba(0, 0, 0, 0.5)"
                    }
                }
            )

        with column_3:
            card(
                title="HTS Assistant",
                text="Customs Cargo Coding Assistant",
                image=image_data("images/sharepoint.jpg"),
                on_click=lambda: navigate("HTS"),
                key='card7',
                styles={
                        "card": {
                            "width": "100%",
                            "height": "350px",
                            "border-radius": "20px",
                            "box-shadow": "0 0 10px rgba(200,200,200,0.5)",
                        },
                        "filter": {
                            "background-color": "rgba(0, 0, 0, 0.5)"
                        }
                }
            )
        
        column_4, column_5, column_6 = st.columns([1, 1, 1])
        
        with column_4:
            card(
                title="Coding Assistant",
                text="From text to code in minutes...",
                image=image_data("images/code.jpg"),
                on_click=lambda: navigate("Coding"),
                key='card4',
                styles={
                        "card": {
                        "width": "100%",
                        "height": "350px",
                        "border-radius": "20px",
                        "box-shadow": "0 0 10px rgba(200,200,200,0.5)",
                    },
                    "filter": {
                        "background-color": "rgba(0, 0, 0, 0.5)"
                    }
                }
            )

        with column_5:
            card(
                title="Entity Extraction Assistant",
                text="Build knowledge graphs with ease",
                image=image_data("images/competition.jpg"),
                on_click=lambda: navigate("Entity"),
                key='card5',
                styles={
                        "card": {
                        "width": "100%",
                        "height": "350px",
                        "border-radius": "20px",
                        "box-shadow": "0 0 10px rgba(200,200,200,0.5)",
                    },
                    "filter": {
                        "background-color": "rgba(0, 0, 0, 0.5)"
                    }
                }
            )

        with column_6:
            card(
                title="Powerpoint Assistant",
                text="10 Second Slides",
                image=image_data("images/powerpoint.jpg"),
                on_click=lambda: navigate("Powerpoint"),
                key='card6',
                styles={
                        "card": {
                        "width": "100%",
                        "height": "350px",
                        "border-radius": "20px",
                        "box-shadow": "0 0 10px rgba(200,200,200,0.5)",
                    },
                    "filter": {
                        "background-color": "rgba(0, 0, 0, 0.5)"
                    }
                }
            )
    
if st.session_state.page == "Catalog":
    catalog_assistant.show()
elif st.session_state.page == "Search":
    search_assistant.show()
elif st.session_state.page == "HTS":
    hts_assistant.show()
elif st.session_state.page == "Coding":
    coding_assistant.show()
elif st.session_state.page == "Entity":
    extraction_assistant.show()
elif st.session_state.page == "Powerpoint":
    powerpoint_assistant.show()
update_ollama_status()

# Execute the main function
if __name__ == "__main__":
    show()