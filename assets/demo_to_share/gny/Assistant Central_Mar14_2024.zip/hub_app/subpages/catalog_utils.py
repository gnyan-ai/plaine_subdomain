from contextlib import contextmanager
import pandas as pd
import os
import json
import hashlib
import concurrent.futures
import functools
import pmdarima
from sqlalchemy import create_engine, text
from .llm_utils import llm_decorator
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import streamlit as st
from .elastic_client import create_bulk_es_index

empty_frame = pd.DataFrame([], columns=['table_catalog', 'table_schema', 'table_name', 'column_name', 'ordinal_position', 'column_default', 'is_nullable', 'data_type', 'columns', 'table_description', 'sample_values', 'column_description', 'table_hash'])
empty_tbl_desc = pd.DataFrame([], columns=['table_hash', 'table_catalog', 'table_schema', 'table_name', 'columns', 'table_description', 'column_descriptions'])

@contextmanager
def postgres_db_connection():
    conn = st.connection("annotation_connection", type='sql')
    try:
        yield conn
    except Exception as e:
        print(f"Exception: {e}")

@contextmanager
def descriptions_db_connection():
    db_config = st.secrets["annotation_connection"]    
    try:
        engine = create_engine(db_config['url'], execution_options={"autocommit": True})
        conn = engine.connect()
        yield conn
    except Exception as e:
        print(f"Exception: {e}")
    finally:
        conn.close()

# Function to persist DataFrame to PostgreSQL
def persist_to_postgresql(df, table_name):
    # Connect to the PostgreSQL database
    db_url = st.secrets["adhoc_connection"]['url']
    engine = create_engine(db_url)
    # Write DataFrame to PostgreSQL
    df.to_sql(table_name, engine, if_exists='replace', index=False, method='multi', chunksize=10000)
    conn = st.connection(f"uploads", type='sql', ttl=10).connect()
    conn.execute(text("USE uploads.public"))
    conn.execute(text("CALL system.flush_metadata_cache()"))
    conn.close()

# Create a PostgreSQL database to store the table metadata
def create_table_metadata_db():
    query = "SELECT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'table_metadata')"
    with postgres_db_connection() as conn:
        result = conn.execute(query)
        table_exists = result.fetchone()[0]
        # If the table does not exist, create it using empty_frame
        if not table_exists:
            empty_frame.to_sql('table_metadata', conn, if_exists='replace', index=False)

def wrap_df(warehouse_ddl):
    for col in empty_frame.columns:
        if col not in warehouse_ddl.columns:
            warehouse_ddl[col] = None 
    warehouse_ddl['table_hash'] = warehouse_ddl.apply(lambda x: generate_table_hash(x.table_schema, x.table_name, x.column_name, x.ordinal_position, x.column_default, x.is_nullable, x.data_type), axis=1)
    return warehouse_ddl[empty_frame.columns]
    
def get_trino_metadata(catalog, schema=None):
    try:
        conn = st.connection(f"{catalog}", type='sql', ttl=10)
        query = f"""select "table_schema", "table_name", "column_name", "ordinal_position", "column_default", "is_nullable", "data_type" from information_schema.columns {f"where table_schema = '{schema}'" if schema else ""} order by table_schema, table_name, ordinal_position"""
        df = conn.query(query)
        df['table_catalog'] = catalog
        return wrap_df(df)
    except Exception as e:
        print(f"Exception: {e}")
        return wrap_df(empty_frame)

def get_trino_catalogs(catalog='minio'):
    try:
        conn = st.connection(f"{catalog}", type='sql', ttl=10)
        query = f"""show catalogs"""
        df = conn.query(query)
        return df
    except Exception as e:
        print(f"Exception: {e}")
        pass

def get_all_trino_metadata():
    catalogs = get_trino_catalogs()
    pdf = pd.concat([get_trino_metadata(catalog) for catalog in catalogs['Catalog'].unique().tolist()], ignore_index=True).reset_index(drop=True)
    return wrap_df(pdf)

# Refresh data
def refresh_schema():
    init_table = get_all_trino_metadata()
    with postgres_db_connection() as conn:
        init_table.to_sql('table_metadata', conn, if_exists='replace', index=False)
    return init_table

def wrap_ddf(pdf):
    for col in empty_tbl_desc.columns:
        if col not in pdf.columns:
            pdf[col] = None 
    pdf['table_hash'] = pdf.apply(lambda x: x.table_hash if not pd.isna(x.table_hash) else generate_table_hash(x.table_catalog, x.table_schema, x.table_name, x.columns), axis=1)
    return pdf[empty_tbl_desc.columns]

# Get the pandas from sql
def get_annotated_catalog():
    with descriptions_db_connection() as conn:
        try:
            query = "SELECT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'table_descriptions')"
            result = conn.execute(text(query))
            table_exists = result.fetchone()[0]
        except Exception as e:
            print(f"Exception: {e}")
            table_exists = False
        print(f"Table exists: {table_exists}")
        if table_exists:
            pdf = pd.read_sql('SELECT * FROM table_descriptions', conn)
            return wrap_ddf(pdf)
        else:
            pdf = empty_tbl_desc
            return wrap_ddf(pdf)
    
def save_annotated_catalog(pdf):
    try:
        with descriptions_db_connection() as conn:
            merged_data = wrap_ddf(pd.concat([get_annotated_catalog(), wrap_ddf(pdf)]).drop_duplicates(subset=['table_hash'], keep='last'))
            merged_data.to_sql('table_descriptions', conn, if_exists='replace', index=False, method='multi', chunksize=1000)
    except Exception as e:
        print(f"Exception: {e}")
        raise e
    
initialized = 'initialized' in st.session_state
if not initialized:
    create_table_metadata_db()
    st.session_state.initialized = True

# Create a idempotent hashing function that generates a unique name for a table given a table_schema and table_name
def generate_table_hash(*args):
    # use md5 hash to generate a unique name
    return hashlib.md5(''.join(map(str,args)).encode('utf-8')).hexdigest()


@llm_decorator()
def generate_table_description(llm, catalog_name, schema_name, table_name, columns, **kwargs):
    from langchain.prompts import PromptTemplate
    content_string = """You are an EXPERT data analyst.
You are given a table name, and a list of columns (in JSON format) in the table of a data warehouse.
You are to write a short business description of the table in 10 sentences (500 characters) or less to allow business community to discover the assets in the warehouse.
YOU ARE NOT ALLOWED to produce any binary or non-text content.
You MUST respond with a string description ONLY, nothing extra, preferably in a single line.
You may be supplied with schema and catalog information, ONLY TO help your analysis but do NOT add any of this warehouse information in your response.
Surround response in backticks ```.

Example Input: {{'catalog':'catalog', 'schema':'test', 'table': 'customer', 'columns': ['customer_id:integer', 'customer_age:decimal', 'customer_dob:date', 'customer_name:varchar', 'customer_address:varchar', 'customer_phone:varchar', 'customer_email:varchar']}}
Example Output: ```The table is a list of customers. Each customer has a unique customer_id, a name, a residential address, contact phone, and a business email. This customer master information can be used for CRM purposes.```

Analyze deeply: take a deep breath and be exhaustive in your analysis.
Now, use the following JSON as your input:
    {{'catalog':'{catalog}', 'schema':'{schema}', 'table': '{table}', 'columns': {columns}}}
Description: ```
"""
    file_llm_chain = PromptTemplate.from_template(content_string) | llm
    result = file_llm_chain.invoke(input={'catalog':catalog_name, 'schema': schema_name, 'table':table_name, 'columns':json.dumps(columns)})
    table_description = result.strip().lstrip('`').rstrip('`').strip().lstrip('[').rstrip(']').strip()
    return table_description


@llm_decorator()
def generate_column_description(llm, catalog_name, schema_name, table_name, columns, table_description, column_name, **kwargs):
    from langchain.prompts import PromptTemplate
    content_string = """You are an EXPERT data analyst.
You are given a table name, a list of columns (in JSON format) in the table of a data warehouse.
You will also receive a text description of the table. Finally, you will be presented with a focal column -- one of the table columns -- that is our analysis target.
You are to write a short business description of the focal column in 1 sentence (72 characters) or less to allow business community to understand that focal column better.
YOU ARE NOT ALLOWED to produce any binary or non-text content.
You MUST respond with a string description ONLY, nothing extra, preferably in a single line. Use simple natural English and avoid technical jargon.
You may be supplied with schema and catalog information, ONLY TO help your analysis but do NOT add any of this warehouse information in your response.
Surround response in backticks ```.

Example Input: {{'catalog':'catalog', 'schema':'test', 'table': 'customer', 'columns': ['customer_id:integer', 'customer_age:decimal', 'customer_dob:date', 'customer_name:varchar', 'customer_address:varchar', 'customer_phone:varchar', 'customer_email:varchar'], 'focal_column': 'customer_email:varchar'}}
Example Output: ```The customer_email contains the email address of the customer (used for email marketing test).```

Analyze deeply: take a deep breath and be exhaustive in your analysis.
Now, use the following JSON as your input:
    {{'catalog':'{catalog}', 'schema':'{schema}', 'table': '{table}', 'columns': {columns}, 'table_description':'{table_description}', 'focal_column': '{column_name}'}}
Column Description: ```
"""
    file_llm_chain = PromptTemplate.from_template(content_string) | llm
    result = file_llm_chain.invoke(input={'catalog':catalog_name, 'schema': schema_name, 'table':table_name, 'columns':json.dumps(columns), 'table_description':table_description, 'column_name':column_name})
    return result.strip().lstrip('`').rstrip('`').strip().lstrip('[').rstrip(']').strip()

@st.cache_data
def get_table_column_sample(table_name, column_name, schema='default', n=5):
    sample = execute_trino_query(f"""select cast(array_agg("{column_name}") as json) sample_values from (select "{column_name}" from "{schema}"."{table_name}" tablesample bernoulli ({n}) limit {n}) x""")
    return sample.sample_values[0] if sample is not None and len(sample) > 0 else None
