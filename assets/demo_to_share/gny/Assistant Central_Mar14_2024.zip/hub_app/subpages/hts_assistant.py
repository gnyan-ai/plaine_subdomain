from collections import defaultdict
import shutil
import streamlit as st
import os
import json
import pandas as pd
import time
from .catalog_utils import get_annotated_catalog
from .llm_utils import get_llm, llm_decorator, StreamlitMarkdownProgressHandler
import extra_streamlit_components as stx
import streamlit_antd_components as sac
import pandas as pd
import numpy as np
from .elastic_client import get_es, get_model
from langchain_community.chat_message_histories import StreamlitChatMessageHistory
from langchain.memory import ConversationBufferMemory
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableLambda, RunnablePassthrough

if not 'search' in st.session_state:
    st.session_state.search = {}
state = st.session_state.search

if 'es' not in state:
    state['es'] = get_es()

# Function to retrieve all available indices


def get_indices():
    es = state['es']
    indices = es.indices.get_alias().keys()
    return list(filter(lambda x: x.lstrip('.') == x, indices))
# Function to retrieve field names from index mappings


def get_field_names(index):
    es = state['es']
    mappings = es.indices.get_mapping(index=index)
    properties = mappings[index]['mappings']['properties']
    field_names = [field for field in properties.keys()]
    return field_names

# Function to identify the vector search field


def get_vector_search_fields(field_names):
    return [field for field in field_names if field.endswith('_embedding')]


def pandas_results(results):
    def _assimilate_score(result):
        result_dict = result["_source"]
        result_dict.update({"score": result["_score"]})
        result_dict.update({"_id": result["_id"]})
        return result_dict
    answer_df = pd.DataFrame.from_dict([_assimilate_score(
        result) for result in results if result and '_source' in result])
    answer_df.drop(columns=[
                   col for col in answer_df.columns if '_embedding' in col], inplace=True, errors='ignore')
    if 'score' not in answer_df.columns:
        answer_df['score'] = 0
    if '_id' not in answer_df.columns:
        answer_df['_id'] = 0
    return answer_df


def perform_vector_search(index, query, vector_fields, n=10):
    if not vector_fields:
        return []
    model = get_model()
    vector = model.encode([query])[0]
    es = state['es']
    results = es.search(
        index=index,
        knn=[
            {
                "field": field,
                "query_vector": vector,
                "num_candidates": 10*n,
                "k": 4*n,
            } for field in vector_fields
        ],
        size=n
    )
    return results["hits"]["hits"]

# Function to perform text search


def perform_text_search(index, query, field_names, n=10):
    if not field_names:
        return []
    es = state['es']
    text_fields = []  # List to store text type fields

    # Retrieve the mapping of the index
    index_mapping = es.indices.get_mapping(index=index)

    # Iterate over the field names and check if they are of text type
    for field in field_names:
        if field in index_mapping[index]['mappings']['properties']:
            field_type = index_mapping[index]['mappings']['properties'][field]['type']
            if field_type == 'text':
                text_fields.append(field)

    should_queries = []
    if not text_fields:
        return []
    for field in text_fields:
        should_queries.append({"match": {field: query}})
    results = es.search(
        index=index,
        body={
            "query": {
                "bool": {
                    "should": should_queries
                }
            }
        },
        size=n
    )
    return results["hits"]["hits"]


def draw_header(icon, text): return sac.divider(
    label=text, icon=icon, align='center', color='gray')


def combine_results(text_results, vector_results, n=10):
    original_columns = [col for col in list(set(vector_results.columns.tolist(
    ) + text_results.columns.tolist())) if not col.endswith('_embedding')]
    for col in original_columns:
        text_results[col] = text_results[col] if col in text_results.columns else None
        vector_results[col] = vector_results[col] if col in vector_results.columns else None

    def combine_scores(row):
        text_score = row['score_text'] if not pd.isna(
            row['score_text']) else 0  # Actual score from text search
        vector_score = row['score_vector'] if not pd.isna(
            row['score_vector']) else 0  # Actual score from vector search
        combined_score = (1*text_score + 3*vector_score)/4.0
        return combined_score

    # Example usage:
    # Merge text_results and vector_results using full outer join on '_id' field
    text_results['score'] = text_results['score']/text_results['score'].max()
    vector_results['score'] = vector_results['score'] / \
        vector_results['score'].max()
    combined_results = pd.merge(text_results.nlargest(n, 'score'), vector_results.nlargest(
        n, 'score'), how='outer', on='_id', suffixes=('_text', '_vector'))
    text_results.set_index('_id', inplace=True)
    vector_results.set_index('_id', inplace=True)
    # Calculate combined scores using apply along rows
    combined_results['combined_score'] = combined_results.apply(
        combine_scores, axis=1)
    combined_results = combined_results.nlargest(n, 'combined_score')
    combined_results.set_index('_id', inplace=True)
    combined_results = combined_results[combined_results.combined_score >= 0.7]
    combined_results['combined_score'] = (
        combined_results['combined_score']*100.0).astype(int).astype(str) + "%"
    cols = []
    for col in original_columns:
        if col in ['_id', 'score']:
            continue
        combined_results[col] = combined_results.apply(lambda row: (text_results.loc[row.name][col] if row.name in text_results.index else None) or (
            vector_results.loc[row.name][col] if row.name in vector_results.index else None), axis=1)
        cols.append(col)
    result = combined_results[cols + ['combined_score']]
    return result


@llm_decorator()
def expand_query(llm, question, **kwargs):
    template = """Given a natural language query, parse the core concept of the intent and recommend upto three keywords of the concept in JSON format, preferably in a single line. ONLY keywords are expected in the response, NOTHING MORE. Your response CANNOT exceed 10 words. The JSON format should be as follows: ```["keyword1", "keyword2", "keyword3"]```. For an example `what is icecream?`, your response will look like ```["ice cream", "frozen dessert", "dairy food"]```.
If you encounter pluralized query, return the singular form of the keyword. For example, if the query is `what are icecreams?`, your response will look like ```["ice cream", "frozen dessert", "dairy food"]```.
Query: `{question}`
Keywords: ```"""
    prompt = ChatPromptTemplate.from_template(template)
    chain = prompt | llm | StrOutputParser()
    return chain.invoke({'question': question}).strip().strip('```').strip()


@llm_decorator()
def get_rag_answer(llm, question, pdf, **kwargs):
    passages = pdf[['Code', 'HierarchicDescription']].to_json(orient='records')
    template = """User will enter a few terms. User is looking for a code and description that is most relevant to their terms.
Rank the following passages against the user's terms and select ONE passage before responding with ONLY ONE MOST RELEVANT passage. Each passage is a JSON record with code and description.
Your response should be in the following format:
```{{"code":"<Code>", "description":"<Passage>", "explanation":"<Explanation>"}}``` 
where <Explanation> is a brief reasoning for match.

For example, if the user's terms are "Frozen Milk", "Dairy Products", "Solid Dairy Products", and the passages are as follows:
```[{{"Code":"786532", "Description":"Covers minerals and metals."}}, {{"Code":"153467", "Description":"Covers fashion apparel."}}, {{"Code":"040221", "Description":"Covers all dairy products solid & frozen."}}, {{"Code":"950346", "Description":"Includes children's toys and playthings."}}, {{"Code":"645787", "Description":"Cows and horse hair."}}]```,
your response will be JSON: ```{{"code":"040221", "description":"Covers all dairy products solid & frozen.", "explanation": "The code 040221 is the most relevant to the user's interests of frozen dairy products."}}```

You are prohibited from returning any codes and descriptions that are NOT in the passages.
If you don't know the answer, return ```{{"code":"000000", "description":"None", "explanation": "None of the said descriptions match the user terms well."}}```. DO NOT try to make up an answer. 

Terms: `{question}`
Passages: ```{passages}```
Response: ```
"""
    prompt = ChatPromptTemplate.from_template(template)
    chain = prompt | llm | StrOutputParser()
    return chain.invoke({'question': question, 'passages': passages}).strip().strip('```').strip()


def show():
    st.markdown(f"<h1 style='text-align: center;'>Accurate Cargo Coding</h1>", unsafe_allow_html=True)
    container = st.container()
    indexes = [idx for idx in get_indices() if 'hs' in idx.lower()]
    menu_box = container.container()
    search_box = menu_box.empty()
    fields = menu_box.empty()
    links = menu_box.empty()

    chat_results = container.container()
    if indexes:
        with menu_box:
            if len(indexes) < 8:
                btns = sac.segmented([sac.SegmentedItem(
                    label=idx, icon='search',) for idx in indexes], align='center', return_index=True)
            else:
                btns = sac.tabs([sac.TabsItem(label=idx)
                                for idx in indexes], return_index=True)
            state['index'] = indexes[btns]
            selected_index = state['index']
            # Retrieve field names from index mappings
            field_names = get_field_names(selected_index)
            vector_search_fields = get_vector_search_fields(field_names)
            textbox = st.text_input(
                label=f'Search', help='Enter your search query here')
            search_btn = sac.buttons([
                # sac.MenuItem('', disabled=True),
                sac.ButtonsItem(label='Search', icon='search',
                                color='#25C3B0'),
            ], align='center')
            if search_btn and textbox:
                expanded_tags = expand_query(textbox)
                expanded_query = f"{expanded_tags}"
                tags = json.loads(expanded_tags) + [textbox]
                sac.tags([sac.Tag(label=tag, icon='tag', link='https://ant.design/components/tag')
                         for tag in tags], align='center', size='lg', radius='sm')
                st.markdown("---")
                text_results = pandas_results(perform_text_search(selected_index, expanded_query, [
                                              field for field in field_names if not field.endswith('_embedding')]))
                vector_results = pandas_results(perform_vector_search(
                    selected_index, expanded_query, vector_search_fields))
                combined_results = combine_results(
                    text_results, vector_results, 8)
                col1, col2 = chat_results.columns([7, 5])
                col1.dataframe(combined_results, use_container_width=True)
                col2_md = col2.empty()
                answer = get_rag_answer(
                    expanded_query, pdf=combined_results, md_output=StreamlitMarkdownProgressHandler(col2_md))
                col2_md.write(answer)
                links_md = col2.container()
                links_md.markdown("---")
                with links_md:
                    sac.buttons([
                        sac.ButtonsItem(label='Verbatim', icon='link', href=f'https://hts.usitc.gov/search?query={textbox}'),
                        sac.ButtonsItem(label='Expanded', icon='link', href=f'https://hts.usitc.gov/search?query={" ".join(tags)}')], label='USITC Search', align='center')


# Execute the main function
if __name__ == "__main__":
    show()
