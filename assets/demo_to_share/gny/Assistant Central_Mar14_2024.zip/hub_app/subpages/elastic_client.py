import pandas as pd
import ast
from elasticsearch import Elasticsearch
from sentence_transformers import SentenceTransformer

# Variables
INDEX_NAME = 'vector_search'
ES_HOST = 'https://es01:9200'
ES_USER = 'elastic'
ES_PASSWORD = 'password'

# Load dataset
def load_dataset(dataset):
    if 'column_descriptions' in dataset.columns:
        dataset['column_description'] = dataset['column_descriptions'].apply(ast.literal_eval)
        dataset = dataset.drop('column_descriptions', axis=1).explode('column_description')
        dataset['column_name'] = dataset['column_description'].apply(lambda x: x[0] if x else None)
        dataset['column_description'] = dataset['column_description'].apply(lambda x: x[1] if x else None)
    dataset['id'] = dataset.reset_index().index
    dataset.set_index('id', inplace=True)
    return dataset

# Create Elasticsearch index
def create_es_index(es, index_name, mapping, settings, dataset, overwrite=False):
    if overwrite and es.indices.exists(index=index_name):
        es.indices.delete(index=index_name)

    if not es.indices.exists(index=index_name):
        es.indices.create(index=index_name, mappings=mapping, settings=settings)
    
    for idx, row in dataset.iterrows():
        document_id = f"{row['table_catalog']}_{row['table_schema']}_{row['table_name']}_{row['column_name']}"
        # Check if document exists
        if not es.exists(index=index_name, id=document_id):
            es.index(index=index_name, id=document_id, body=dict(row))

# Perform search
def perform_search(es, index_name, query, n=10):
    vector = model.encode([query])[0]
    results = es.search(
        index=index_name,
        knn=[
            {
                "field": "table_description_embedding",
                "query_vector": vector,
                "num_candidates": 10*n,
                "k": 4*n,
            },
            {
                "field": "column_description_embedding",
                "query_vector": vector,
                "num_candidates": 10*n,
                "k": 4*n,
            }
        ],
        size=n
    )
    return results["hits"]["hits"]

# Define Elasticsearch index mapping and settings
index_mapping = {
    "properties": {
        "table_catalog": {"type": "text", "fields": {"keyword": {"type": "keyword", "ignore_above": 256}}},
        "table_schema": {"type": "text", "fields": {"keyword": {"type": "keyword", "ignore_above": 256}}},
        "table_name": {"type": "text", "fields": {"keyword": {"type": "keyword", "ignore_above": 256}}},
        "column_name": {"type": "text", "fields": {"keyword": {"type": "keyword", "ignore_above": 256}}},
        "table_description": {"type": "text", "fields": {"keyword": {"type": "keyword", "ignore_above": 1024}}},
        "column_description": {"type": "text", "fields": {"keyword": {"type": "keyword", "ignore_above": 1024}}},
        "table_description_embedding": {"type": "dense_vector", "dims": 384, "index": True, "similarity": "l2_norm"},
        "column_description_embedding": {"type": "dense_vector", "dims": 384, "index": True, "similarity": "l2_norm"},
    }
}

index_settings = {"index": {"number_of_replicas": "1", "number_of_shards": "1"}}

# Define Elasticsearch connection
model = None

def get_model():
    global model
    if model is None:
        model = SentenceTransformer("all-MiniLM-L6-v2")
    return model

model = get_model()

# Expose a function that can be used to create the index with only index name, dataset, and overwrite
def create_index(index_name, dataset, overwrite=False):
    dataset = load_dataset(dataset)
    if not 'table_description_embedding' in dataset.columns:
        dataset['table_description_embedding'] = model.encode(dataset['table_description'].fillna('').astype(str)).tolist()
    if not 'column_description_embedding' in dataset.columns:
        dataset['column_description_embedding'] = model.encode(dataset['column_description'].fillna('').astype(str)).tolist()
    es = Elasticsearch(hosts=[ES_HOST], verify_certs=False, http_auth=(ES_USER, ES_PASSWORD))
    create_es_index(es, index_name, index_mapping, index_settings, dataset, overwrite=overwrite)

from elasticsearch import Elasticsearch
from elasticsearch.helpers import bulk
import pandas as pd

def generate_embeddings(df, text_fields):
    for i, column in enumerate(text_fields):
        df[f"{column}_embedding"] = get_model().encode(df[column].fillna('').astype(str)).tolist()

def create_index_mapping(df, text_columns):
    mapping = {"properties": {}}
    for column in df.columns:
        if column in text_columns:
            mapping["properties"][column] = {"type": "text"}
            mapping["properties"][f"{column}_embedding"] = {"type": "dense_vector", "dims": 384}
    return mapping

# Expose a function that can be used to create the index with only index name, dataset, and overwrite
def create_bulk_es_index(index_name, dataset):
    from elasticsearch.helpers import bulk
    text_columns = [col for col, dtype in dataset.dtypes.items() if dtype == 'object']
    dataset = dataset.fillna('').astype(str)
    generate_embeddings(dataset, text_columns)
    index_mapping = create_index_mapping(dataset, text_columns)
    es = Elasticsearch(hosts=[ES_HOST], verify_certs=False, http_auth=(ES_USER, ES_PASSWORD))
    if es.indices.exists(index=index_name):
        es.indices.delete(index=index_name)
    es.indices.create(index=index_name, body={"mappings": index_mapping}, ignore=400)
    actions = [
        {
            "_index": index_name,
            "_id": idx,
            "_source": row.to_dict()
        }
        for idx, row in dataset.iterrows()
    ]
    success, failed = bulk(es, actions)
    return success, failed

def get_es():
    return Elasticsearch(hosts=[ES_HOST], verify_certs=False, http_auth=(ES_USER, ES_PASSWORD))

# Expose a function that can be used to perform search with only index name and query
def search_vector(index_name, query, n=10):
    es = get_es()
    return perform_search(es, index_name, query, n)

def text_search(index_name, query, n=10):
    es = Elasticsearch(hosts=[ES_HOST], verify_certs=False, http_auth=(ES_USER, ES_PASSWORD))
    results = es.search(
        index=index_name,
        body={
            "query": {
                "bool": {
                    "should": [
                        {"match": {"table_catalog": query}},
                        {"match": {"table_schema": query}},
                        {"match": {"table_name": query}},
                        {"match": {"column_name": query}},
                        {"match": {"table_description": query}},
                        {"match": {"column_description": query}}
                    ]
                }
            },
            "size": n
        }
    )
    return results["hits"]["hits"]

# Show search results
def pandas_results(results):
    def _assimilate_score(result):
        result_dict = result["_source"]
        result_dict.update({"score": result["_score"]})
        return result_dict
    answer_df = pd.DataFrame.from_dict([_assimilate_score(result) for result in results if result and '_source' in result])
    return answer_df.groupby(['table_catalog', 'table_schema', 'table_name']).agg({'score': sum, 'column_name': lambda z: [y.strip() for y in z]}).sort_values(by='score', ascending=False) if not answer_df.empty else answer_df
