from collections import defaultdict
from datetime import datetime
import shutil
import time
import json
import streamlit as st
import extra_streamlit_components as stx
import streamlit_antd_components as sac
from .catalog_utils import refresh_schema, get_annotated_catalog, save_annotated_catalog, get_all_trino_metadata, generate_table_description, generate_column_description, persist_to_postgresql
from .llm_utils import get_markdown_handler
import pandas as pd
from .elastic_client import create_index, pandas_results, text_search, create_bulk_es_index

if not 'catalog' in st.session_state:
    st.session_state.catalog = {}
state = st.session_state.catalog


def draw_header(icon, text): return sac.divider(
    label=text, icon=icon, align='center', color='gray')

# Step 0: Upload ad hoc dataset


def upload_step():
    draw_header("upload", "Adhoc Upload")
    upload_view = st.container()
    # Streamlit UI
    # File upload section
    browse_view, preview = upload_view.columns([1, 3])
    file = browse_view.file_uploader("Upload a CSV file", type=[
                                     'csv', 'xlsx', 'parquet'])
    
    def read_file(file):
        if file.type == 'application/vnd.ms-excel' or 'application/vnd.openxmlformats-officedocument' in file.type:
            try:
                df = pd.read_excel(file)
            except Exception as e:
                st.error(f"Error reading Excel file: {e}")
                return None
        elif file.type == 'text/csv':
            try:
                df = pd.read_csv(file)
            except Exception as e:
                st.error(f"Error reading CSV file: {e}")
                return None
        elif file.type == 'application/octet-stream':  # Parquet
            try:
                df = pd.read_parquet(file)
            except Exception as e:
                st.error(f"Error reading Parquet file: {e}")
                return None
        else:
            st.error(f"Unsupported file format -- {file.type}. Please upload a CSV, XLSX, or Parquet file.")
            return None
        
        return df
    if file is not None:
        # Load data into DataFrame
        df = read_file(file)
        if df is not None:
            # Display DataFrame
            preview.write("Preview of the DataFrame (first 10 rows):")
            preview.dataframe(df.head(10))

        # Get table name from file name
        file_name = file.name.split('.')[0]
        table_name = preview.text_input("Enter table name", value=file_name,
                                        help="Enter the name of the table to persist to the data warehouse")
        # Button to persist DataFrame to PostgreSQL
        cols = preview.columns(5)
        if cols[2].button("Persist DataFrame to PostgreSQL"):
            with st.spinner(f"Saving to `uploads`.`public`.`{table_name}`"):
                persist_to_postgresql(df, table_name)
                preview.success(
                    f"DataFrame persisted to PostgreSQL table: `uploads`.`public`.`{table_name}`")
        if cols[3].button("Persist DataFrame to ElasticSearch"):
            with st.spinner(f"Indexing to `{table_name}`"):
                create_bulk_es_index(table_name, df)
                preview.success(
                    f"DataFrame indexed to Elastic Search: `{table_name}`")

# Step 1: Inventory


def inventory_step():
    if 'inventory' in state:
        del state['inventory']
    draw_header("search", "Inventory")
    # Create subtext filters for filtering table_catalog, table_schema, table_name
    filter_columns = st.columns(3)
    dframe_view = st.empty()
    # Retrieve filter values from session state
    table_catalog_filter = state.get('table_catalog', '')
    table_schema_filter = state.get('table_schema', '')
    table_name_filter = state.get('table_name', '')

    # Create subtext filters for filtering table_catalog, table_schema, table_name
    table_catalog_filter = filter_columns[0].text_input(
        "Catalog", value=table_catalog_filter, help="Filter by table catalog subtext")
    table_schema_filter = filter_columns[1].text_input(
        "Schema", value=table_schema_filter, help="Filter by table schema/dataabase subtext")
    table_name_filter = filter_columns[2].text_input(
        "Name", value=table_name_filter, help="Filter by table name subtext")

    # Save filter values to session state
    state['table_catalog'] = table_catalog_filter
    state['table_schema'] = table_schema_filter
    state['table_name'] = table_name_filter
    # Filter the data based on the subtext filters
    with st.spinner("Collecting Inventory..."):
        filtered_data = get_all_trino_metadata()
        if table_catalog_filter:
            filtered_data = filtered_data[filtered_data['table_catalog'].str.contains(
                table_catalog_filter, case=False)]
        if table_schema_filter:
            filtered_data = filtered_data[filtered_data['table_schema'].str.contains(
                table_schema_filter, case=False)]
        if table_name_filter:
            filtered_data = filtered_data[filtered_data['table_name'].str.contains(
                table_name_filter, case=False)]
        # Display the filtered data
        if not filtered_data.empty:
            dframe_view.dataframe(
                filtered_data[filtered_data.columns[:5]], use_container_width=True)
        else:
            dframe_view.error("No data found")
        state['inventory'] = filtered_data
        if 'tables_inventory' in state:
            del state['tables_inventory']

# Step 2: Sample


def analyze_step():
    if 'tables_inventory' in state:
        del state['tables_inventory']
    draw_header("database", "Filter")
    with st.spinner("Ordering Tables..."):
        inventory_view = st.empty()
        if 'inventory' in state:
            filtered_data = state['inventory']
            filtered_data['column_type'] = filtered_data['column_name'] + \
                ':' + filtered_data['data_type']
            state['tables_inventory'] = filtered_data.sort_values(by=['table_catalog', 'table_schema', 'table_name', 'ordinal_position', 'column_type']).drop_duplicates(
                subset=['table_catalog', 'table_schema', 'table_name', 'ordinal_position', 'column_type']).groupby(['table_catalog', 'table_schema', 'table_name']).agg({'column_type': list}).reset_index().rename(columns={'column_type': 'columns'})
            inventory_view.dataframe(
                state['tables_inventory'], use_container_width=True)
            if 'cataloged_inventory' in state:
                del state['cataloged_inventory']
        else:
            inventory_view.error("No inventory data found")


# Step 3: Annotate
def annotate_step():
    if 'cataloged_inventory' in state:
        tabular_data = state['cataloged_inventory']
    elif 'tables_inventory' in state:
        tabular_data = state['tables_inventory']
        if 'table_description' not in tabular_data.columns:
            tabular_data['table_description'] = None
        if 'column_descriptions' not in tabular_data.columns:
            tabular_data['column_descriptions'] = None
    else:
        tabular_data = None

    draw_header("code", "Annotate")
    annotation_view = st.empty()
    if tabular_data is None:
        annotation_view.error(
            "No data found. Please go back to the Inventory step and try again.")
        return
    are_there_blank_descriptions = tabular_data['table_description'].isna(
    ).sum() > 0
    progress_view = annotation_view.container()
    if are_there_blank_descriptions:
        cols = progress_view.columns(7)
        btn = cols[3].button("Start Annotation",
                             help="Click to start annotating with AI")
        if btn:
            progress_bar = progress_view.progress(0.0)
            annotate_progress = annotation_view.container()
            # Iterate over each row in tabular_data
            for idx, row in tabular_data.iterrows():
                table = row['table_name']
                schema = row['table_schema']
                catalog = row['table_catalog']
                columns = row['columns']
                progress = (idx + 1) / len(tabular_data)
                progress_bar.progress(
                    progress, f"{int(100*progress)}%. Processing {idx + 1}/{len(tabular_data)}. Annotating {catalog}.{schema}.{table}")
                annotate_progress.markdown("---")
                st_view, col_view = annotate_progress.columns([3, 5])
                if pd.isna(row['table_description']) or not bool(row['table_description']):
                    row['table_description'] = None
                    # Perform annotation
                    header_space = st_view.empty()
                    st_space = st_view.empty()
                    col_view_incr = col_view.empty()
                    header_space.markdown(
                        f"### {catalog}.{schema}.{table}", unsafe_allow_html=True)
                    table_description = generate_table_description(catalog_name=catalog, schema_name=schema, table_name=table, columns=columns,
                                                                   model_name="neural-chat", timeout=60, md_output=get_markdown_handler(st_space, f"{catalog}.{schema}.{table}"), stop=["```", "]]]"])
                    tabular_data.at[idx,
                                    'table_description'] = table_description
                    column_descriptions = []
                    for col in columns:
                        if pd.isna(row['column_descriptions']) or not bool(row['column_descriptions']):
                            row['column_descriptions'] = None
                        if pd.isna(row['column_descriptions']) or not bool(row['column_descriptions']) or not any([col in cd for cd in row['column_descriptions']]):
                            column_descriptions.append((col, generate_column_description(catalog_name=catalog, schema_name=schema, table_name=table, columns=columns,
                                                       table_description=table_description, column_name=col, model_name="neural-chat", timeout=60, md_output=None, stop=["```", "]]]"])))
                            tabular_data.at[idx, 'column_descriptions'] = json.dumps(
                                column_descriptions)
                            state['cataloged_inventory'] = tabular_data
                            col_view_incr.write(pd.DataFrame(json.loads(
                                tabular_data.at[idx, 'column_descriptions'])), use_container_width=True)
                    tabular_data.at[idx, 'column_descriptions'] = json.dumps(
                        column_descriptions)
                    state['cataloged_inventory'] = tabular_data
                # Skip over rows that have already been annotated
                else:
                    header_space = st_view.empty()
                    st_space = st_view.empty()
                    col_view_incr = col_view.empty()
                    header_space.markdown(
                        f"### {catalog}.{schema}.{table}", unsafe_allow_html=True)
                    st_space.write(f"{row['table_description']}")
                    col_view_incr.write(pd.DataFrame(json.loads(
                        tabular_data.at[idx, 'column_descriptions'])), use_container_width=True)
                    continue
            state['cataloged_inventory'] = tabular_data
            # Remove progress bar
            progress_bar.empty()

# Step 3: Annotate


def review_step():
    if 'cataloged_inventory' in state:
        tabular_data = state['cataloged_inventory']
    elif 'tables_inventory' in state:
        tabular_data = state['tables_inventory']
        if 'table_description' not in tabular_data.columns:
            tabular_data['table_description'] = None
    else:
        tabular_data = None
    draw_header("table", "Review")
    cataloged_data_tab = st.container()
    if tabular_data is None:
        cataloged_data_tab.error(
            "No data found. Please go back to the Annotate step and try again.")
        return
    are_there_blank_descriptions = tabular_data['table_description'].isna(
    ).sum() > 0
    cataloged_data_table = cataloged_data_tab.empty()
    cataloged_data_table.empty()
    cataloged_data_table.dataframe(tabular_data, use_container_width=True)
    if not are_there_blank_descriptions:
        cols = cataloged_data_tab.columns(7)
        wipe_button = cols[3].button(
            "Reset Descriptions", help="Click to cleanup any existing descriptions and startover")
        if wipe_button:
            tabular_data['table_description'] = None
            state['cataloged_inventory'] = tabular_data
            cataloged_data_table.empty()
            cataloged_data_table.dataframe(
                tabular_data, use_container_width=True)
            st.rerun()


def persist_table_description(tabular_data):
    tabular_data = tabular_data.dropna(subset=['table_description'])
    if not tabular_data.empty:
        save_annotated_catalog(tabular_data)
        time.sleep(1)
    else:
        st.warning("No data to save")

def es_index(tabular_data):
    tabular_data = tabular_data.dropna(subset=['table_description'])
    if not tabular_data.empty:
        save_annotated_catalog(tabular_data)
        time.sleep(1)
    else:
        st.warning("No data to save")

def index_data():
    tabular_data = take_only_annotated(get_annotated_catalog()).reset_index()
    if not tabular_data.empty:
        create_index("catalog", tabular_data, False)
    else:
        st.warning("No data to save")


def take_only_annotated(tabular_data):
    if 'column_descriptions' in tabular_data.columns:
        tabular_data.dropna(subset=['column_descriptions'], inplace=True)
        tabular_data['column_description'] = tabular_data['column_descriptions'].apply(
            json.loads)
        tabular_data.drop(columns=['column_descriptions'], inplace=True)
        tabular_data = tabular_data.explode('column_description')
        tabular_data['column_name'] = tabular_data['column_description'].apply(
            lambda x: x[0].strip() if x else None)
        tabular_data['column_description'] = tabular_data['column_description'].apply(
            lambda x: x[1].strip() if x else None)
        return tabular_data.dropna(subset=['table_description'])[['table_catalog', 'table_schema', 'table_name', 'table_description', 'column_name', 'column_description']].set_index(['table_catalog', 'table_schema', 'table_name', 'table_description'])
    else:
        return tabular_data

# Step 4: Save


def save_step():
    draw_header("save", "Save")
    container = st.container()
    menu_box = container.empty()
    actions_box = container.empty()
    if 'cataloged_inventory' in state:
        tabular_data = state['cataloged_inventory']
        if not tabular_data.empty:
            with menu_box:
                btns = sac.segmented([
                    sac.SegmentedItem(label='Download', icon='download'),
                    sac.SegmentedItem(label="Save", icon='save',),
                    sac.SegmentedItem(label='Index', icon='search',)], align='center', return_index=True)
                if btns == 0:
                    csv_data = tabular_data.to_csv(index=False)
                    filename = f"annotated_{datetime.now().strftime('%Y-%m-%d-%H-%M-%S')}.csv"
                    new_btns = container.empty()
                    new_btns.columns(9)[4].download_button(label=f"Click to Download", data=csv_data,
                                                           file_name=filename, mime="text/csv",)
                elif btns == 1:
                    new_btns = actions_box.empty()
                    if actions_box.columns(9)[4].button(label="Save",
                                                        on_click=persist_table_description, args=(tabular_data,)):
                        actions_box.success(
                            "Descriptions have been saved to the data warehouse")
                        df = take_only_annotated(tabular_data.copy())
                        actions_box.write(
                            tabular_data, use_container_width=True)
                elif btns == 2:
                    new_btns = actions_box.empty()
                    if actions_box.columns(9)[4].button(label="Index",
                                                        on_click=index_data, args=()):
                        actions_box.success(
                            "Indexed the data warehouse with the descriptions.")
        else:
            container.warning("No data to save")
    else:
        container.warning(
            "No cataloged inventory found. Showing previous annotations")
        df = take_only_annotated(get_annotated_catalog())
        container.write(df, use_container_width=True)


def show():
    import streamlit_antd_components as sac
    index = sac.segmented(
        items=[
            sac.SegmentedItem(label='Annotate', icon='database'),
            sac.SegmentedItem(label='Search', icon='search'),
        ], label='', align='center', return_index=True, key="catalog_assistant"
    )
    if index == 0:
        st.markdown(f"<h1 style='text-align: center;'>Annotate Datalake</h1>",
                    unsafe_allow_html=True)
        process_tab = sac.steps(
            items=[
                sac.StepsItem(title='Upload',
                              description='Upload (optional) your data'),
                sac.StepsItem(title='Inventory',
                              description='Scan your data warehouse'),
                sac.StepsItem(title='Analyze',
                              description='Filter tables for annotation'),
                sac.StepsItem(title='Annotate',
                              description='Annotate tables with AI'),
                sac.StepsItem(title='Review',
                              description='Review annotated tables'),
                sac.StepsItem(title='Export',
                              description='Save annotations to file'),
            ], return_index=True,)
        if process_tab == 0:
            upload_step()
        elif process_tab == 1:
            inventory_step()
        elif process_tab == 2:
            analyze_step()
        elif process_tab == 3:
            annotate_step()
        elif process_tab == 4:
            review_step()
        elif process_tab == 5:
            save_step()
    elif index == 1:
        st.markdown(f"<h1 style='text-align: center;'>Locate Data</h1>",
                    unsafe_allow_html=True)
        from .elastic_client import search_vector
        with st.form("catalog_search"):
            search_query = st.text_input("Search Query", value="Industry average price of technology stocks in 2017",
                                         help="Enter a natural language query to locate relevant data attributes in the datalake")
            search_button = st.form_submit_button("Search")
            if search_button:
                if 'query_history' not in state:
                    state['query_history'] = []
                if search_query and search_query not in [query['query'] for query in state['query_history']]:
                    with st.spinner("Searching..."): # Perform search operation
                        results_vector = pandas_results(
                            search_vector("catalog", search_query))
                        results_text = pandas_results(
                            text_search("catalog", search_query))
                        # Save query history
                        state['query_history'].append({
                            'query': search_query,
                            'timestamp': datetime.now(),
                            'results_vector': results_vector,
                            'results_text': results_text
                        })
        if st.button("Clear history"):
            state['query_history'] = []
        if 'query_history' in state and state['query_history'][:5]:
            for i, query in enumerate(reversed(state['query_history'][-5:])):
                if query['results_vector'] is None or query['results_text'] is None:
                    continue
                with st.expander(f"Query: {query['query']}", expanded=(i == 0)) as expander:
                    vector_results, text_results = st.columns(2)
                    if query['results_vector'] is not None:
                        vector_results.write("Vector Results:")
                        vector_results.dataframe(query['results_vector'])
                    else:
                        vector_results.warning("No results found.")
                    if query['results_text'] is not None:
                        text_results.write("Text Results:")
                        text_results.dataframe(query['results_text'])
                    else:
                        text_results.warning("No results found.")


# Execute the main function
if __name__ == "__main__":
    show()
