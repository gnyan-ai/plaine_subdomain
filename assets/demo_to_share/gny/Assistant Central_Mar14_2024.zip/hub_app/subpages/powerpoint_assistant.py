from collections import defaultdict
import shutil
import streamlit as st
import os
import json
import pandas as pd
import time
from .catalog_utils import get_annotated_catalog
from .llm_utils import get_llm, llm_decorator, StreamlitMarkdownProgressHandler
import extra_streamlit_components as stx
import streamlit_antd_components as sac
import pandas as pd
import numpy as np
from .elastic_client import get_es, get_model
from langchain_community.chat_message_histories import StreamlitChatMessageHistory
from langchain.memory import ConversationBufferMemory
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableLambda, RunnablePassthrough

if not 'ppt' in st.session_state:
    st.session_state.ppt = {}
state = st.session_state.ppt

def draw_header(icon, text): return sac.divider(
    label=text, icon=icon, align='center', color='gray')

@llm_decorator()
def generate_pptx(llm, topic, **kwargs):
    template = """You are a great technical writer. Write me ~10 slides in JSON format for a presentation on the topic of `{topic}`. Please include slide_number, title, content (a list of bullets), image_url, code_snippet_to_include, tags (list of keywords), citations (optional 1 or 2 "valid" links), and slide_summary (one sentence) per slide. The response should be a JSON list of slides along with slides_heading, slide_count fields.
    slides: ```"""
    prompt = ChatPromptTemplate.from_template(template)
    chain = prompt | llm | StrOutputParser()
    return chain.invoke({'topic': topic}).strip().strip('```').strip()


def show():
    st.markdown(f"<h1 style='text-align: center;'>Expert Research Slides</h1>", unsafe_allow_html=True)
    container = st.container()
    entity_box = container.container()
    slide_results = container.container()
    with entity_box:
        textbox = st.text_area('Topic of Interest', "Habeas Corpus", height=150)
        cols = st.columns(7)
        extract_btn = cols[3].button('Generate Slides')
        if extract_btn and textbox:
            slides_view = entity_box.empty()
            entities = generate_pptx(
                textbox, md_output=StreamlitMarkdownProgressHandler(slides_view))
            slides_view.code(entities)

# Execute the main function
if __name__ == "__main__":
    show()
