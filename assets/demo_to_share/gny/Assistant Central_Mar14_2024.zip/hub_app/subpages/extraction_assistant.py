from collections import defaultdict
import shutil
import streamlit as st
import os
import json
import pandas as pd
import time
from .catalog_utils import get_annotated_catalog
from .llm_utils import get_llm, llm_decorator, StreamlitMarkdownProgressHandler
import extra_streamlit_components as stx
import streamlit_antd_components as sac
import pandas as pd
import numpy as np
from .elastic_client import get_es, get_model
from langchain_community.chat_message_histories import StreamlitChatMessageHistory
from langchain.memory import ConversationBufferMemory
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableLambda, RunnablePassthrough

if not 'extract' in st.session_state:
    st.session_state.extract = {}
state = st.session_state.extract

def draw_header(icon, text): return sac.divider(
    label=text, icon=icon, align='center', color='gray')

p_release = """CBP officers seize over $8.4 million in methamphetamine at World Trade Bridge

Release Date Wed, 03/13/2024

LAREDO, Texas—U.S. Customs and Border Protection, Office of Field Operation officers assigned to the World Trade Bridge seized methamphetamine that totaled over $8,400,000 in street value. 

“Optimal targeting efforts were keen in foiling this drug smuggling attempt,” said Port Director Alberto Flores, Laredo Port of Entry. “CBP personnel are persistent in protecting our Nation against dangerous and prohibited narcotics that pose a threat to our communities.”

Packages containing 923 pounds of methamphetamine seized by CBP officers at World Trade Bridge.

The seizure occurred on Tuesday, March 12 at the World Trade Bridge, when a CBP officer referred a 2021 Volvo tractor and trailer manifesting a commercial shipment of celery, broccoli, and cauliflower for secondary inspection. Following a canine and non-intrusive inspection system examination, CBP officers discovered a total of 923 pounds of alleged methamphetamine within the commodity. 

The narcotics had a street value of $8,493,968.

CBP seized the narcotics. Homeland Security Investigations special agents are leading the investigation. 

Follow the Director of CBP’s Laredo Field Office on Twitter at @DFOLaredo and also U.S. Customs and Border Protection at @CBPSouthTexas for breaking news, current events, human interest stories and photos.
"""

@llm_decorator()
def extract_entities(llm, document, **kwargs):
    template = """Given a large natural language document, recognize and extract all entities in that text.
Kindly extract attributes such as key dates (days, weeks, months, periods), locations (cities, counties, towns, landmarks etc), organizations, persons, currencies, numbers, products, units, titles, and all ancillary entities.
Canonicalize a "master" entity per variant-set by coalescing duplicate entities and collating attributes from multiple variants into a single canonical entity.
Avoid being repetitive.
Your response must be a JSON list of canonical entities (where each canonical entity is a list of collated key-value attributes).
Document: ```{document}```
Canonical Identities: ```"""
    prompt = ChatPromptTemplate.from_template(template)
    chain = prompt | llm | StrOutputParser()
    return chain.invoke({'document': document}).strip().strip('```').strip()


def show():
    st.markdown(f"<h1 style='text-align: center;'>Entity Knowledge Graph</h1>", unsafe_allow_html=True)
    container = st.container()
    entity_box = container.container()
    extraction_results = container.container()
    with entity_box:
        textbox = st.text_area('Press Release', p_release, height=400)
        cols = st.columns(7)
        extract_btn = cols[3].button('Extract')
        if extract_btn and textbox:
            text_entity_view = entity_box.empty()
            entities = extract_entities(
                textbox, md_output=StreamlitMarkdownProgressHandler(text_entity_view))
            text_entity_view.code(entities)

# Execute the main function
if __name__ == "__main__":
    show()
