from collections import defaultdict
import shutil
import streamlit as st
import os
import json
import pandas as pd
import time
from .catalog_utils import get_annotated_catalog
from .llm_utils import get_llm, llm_decorator
import extra_streamlit_components as stx
import streamlit_antd_components as sac
import pandas as pd
import numpy as np
from .elastic_client import get_es, get_model

if not 'search' in st.session_state:
    st.session_state.search = {}
state = st.session_state.search

if 'es' not in state:
    state['es'] = get_es()

# Function to retrieve all available indices


def get_indices():
    es = state['es']
    indices = es.indices.get_alias().keys()
    return list(filter(lambda x: x.lstrip('.') == x, indices))
# Function to retrieve field names from index mappings


def get_field_names(index):
    es = state['es']
    mappings = es.indices.get_mapping(index=index)
    properties = mappings[index]['mappings']['properties']
    field_names = [field for field in properties.keys()]
    return field_names

# Function to identify the vector search field
def get_vector_search_fields(field_names):
    return [field for field in field_names if field.endswith('_embedding')]


def pandas_results(results):
    def _assimilate_score(result):
        result_dict = result["_source"]
        result_dict.update({"score": result["_score"]})
        result_dict.update({"_id": result["_id"]})
        return result_dict
    answer_df = pd.DataFrame.from_dict([_assimilate_score(
        result) for result in results if result and '_source' in result])
    answer_df.drop(columns=[
                   col for col in answer_df.columns if '_embedding' in col], inplace=True, errors='ignore')
    if 'score' not in answer_df.columns:
        answer_df['score'] = 0
    if '_id' not in answer_df.columns:
        answer_df['_id'] = 0
    return answer_df


def perform_vector_search(index, query, vector_fields, n=10):
    if not vector_fields:
        return []
    model = get_model()
    vector = model.encode([query])[0]
    es = state['es']
    results = es.search(
        index=index,
        knn=[
            {
                "field": field,
                "query_vector": vector,
                "num_candidates": 10*n,
                "k": 4*n,
            } for field in vector_fields
        ],
        size=n
    )
    return results["hits"]["hits"]

# Function to perform text search


def perform_text_search(index, query, field_names, n=10):
    if not field_names:
        return []
    es = state['es']
    text_fields = []  # List to store text type fields

    # Retrieve the mapping of the index
    index_mapping = es.indices.get_mapping(index=index)

    # Iterate over the field names and check if they are of text type
    for field in field_names:
        if field in index_mapping[index]['mappings']['properties']:
            field_type = index_mapping[index]['mappings']['properties'][field]['type']
            if field_type == 'text':
                text_fields.append(field)

    should_queries = []
    if not text_fields:
        return []
    for field in text_fields:
        should_queries.append({"match": {field: query}})
    results = es.search(
        index=index,
        body={
            "query": {
                "bool": {
                    "should": should_queries
                }
            }
        },
        size=n
    )
    return results["hits"]["hits"]


def draw_header(icon, text): return sac.divider(
    label=text, icon=icon, align='center', color='gray')

def show():
    st.markdown(f"<h1 style='text-align: center;'>Search the Datalake</h1>", unsafe_allow_html=True)
    container = st.container()
    indexes = get_indices()
    menu_box = container.container()
    search_box = menu_box.empty()
    fields = menu_box.empty()
    links = menu_box.empty()
    
    chat_results = container.container()
    if indexes:
        with menu_box:
            if len(indexes) < 8:
                btns = sac.segmented([sac.SegmentedItem(
                    label=idx, icon='search',) for idx in indexes], align='center', return_index=True)
            else:
                btns = sac.tabs([sac.TabsItem(label=idx)
                                for idx in indexes], return_index=True)
            state['index'] = indexes[btns]
            selected_index = state['index']
            # Retrieve field names from index mappings
            field_names = get_field_names(selected_index)
            vector_search_fields = get_vector_search_fields(field_names)
            selected_fields = sac.tags(
                items=[
                    sac.Tag(label=fld.lower()) for fld in field_names], align='center', radius='xs')
            textbox = st.text_input(
                label=f'Search', help='Enter your search query here')
            search_mode = sac.switch(label='Vector Search', on_label='On',
                                     align='center', size='sm', value=bool(vector_search_fields),)
            search_btn = sac.buttons([
                # sac.MenuItem('', disabled=True),
                sac.ButtonsItem(label='Search', icon='search',
                                color='#25C3B0'),
            ], align='center')
            if search_btn and textbox:
                if search_mode:
                    vector_results = pandas_results(perform_vector_search(
                        selected_index, textbox, vector_search_fields))
                    results = vector_results
                else:
                    text_results = pandas_results(perform_text_search(
                        selected_index, textbox, [field for field in field_names if not field.endswith('_embedding')]))
                    results = text_results
                st.dataframe(results, use_container_width=True)
                cols2  = st.columns(2)
                kibana_host = os.environ.get('KIBANA_HOST', 'http://192.168.27.10:5601')
                cols2[0].markdown(f"View more results in [Kibana]({kibana_host}/app/enterprise_search/content/search_indices/{selected_index}/documents)", unsafe_allow_html=True)
                cols2[1].markdown(f"Visualize in Kibana [Dashboard]({kibana_host}/app/visualize#/create?_g=())", unsafe_allow_html=True)

# Execute the main function
if __name__ == "__main__":
    show()
