**Slide Title: Analytics Hub Scope**

1. **Explore Data Lake**
   - Catalogs, schemas, tables, fields
   - AI-driven data definitions
   - Example: "What does this table contain?"

2. **Midoffice RAG Assistant**
   - Knowledge base enquiry
   - Example: "What room is bound to this customer reservation?"

3. **Frontoffice FAQ Bot**
   - Customer inquiries & reservation extension
   - Example: "Is the Dominos location open, and how can I cancel by order?"

4. **Backoffice Analytics Assistant**
   - SQL coding support
   - Example: "EV vs. ICE state-level decomposition in US vs. EUR?"

5. **Coding Assistant**
   - Code generation, e.g., JDBC/ETL integration
   - Example: "Write JDBC integration between DB2 and Databricks for nightly runs."

6. **CloudOps Assistant**
   - Databricks notebook packaging and scheduling; Docker/K8s/TF
   - Example: "Package Databricks notebook into DBX workflow for nightly execution."

7. **Data Observability**
   - Data quality hygiene in Databricks
   - Example: "Implement data semantics/integrity for schema_a.table_b. Alert when data lags or dies."

8. **Business Observability**
   - Auto-detecting anomalies in metrics
   - Example: "Automatically scan temporal, dimensional, and performance metrics; build anomaly triggers. Trigger when reservations drop over 5% than normal."

9. **Trend Dashboards**
   - Identify trends from lake data
   - Example: "Identify upward, downward, and anomalous trends from lake data in Grafana. Trigger 3P integrations into Teams or Dash PoS"

10. **Stories**
    - Summarize datasets into natural language discourse
    - Example: "Generate client (Intel/Microsoft/IBM) data-as-a-service summative reports."

11. **Competitive Intelligence**
    - Monitor and summarize business vectors
    - Example: "Scan news channels and summarize emerging competitive/transformative business vectors."

12. **Multimodal Assistant**
    - Insights from charts and data
    - Example: "Develop NLU and NLG insights from visual charts. Automatically analyze PowerBI, Tableau, WebFocus, Qlik"

13. **Log/Hotspot Awareness**
    - Identify popular content
    - Example: "Find popular content from logs and queries for portal hub. Enable collaborative filtering."

14. **Data Lake Guidance Advisor**
    - Data governance recommendations
    - Example: "Create a data lake governance advisor based on data patterns -- compression/storage/partitioning/bucketing/indexing/sharding/tiering."

This concise slide provides a clear overview of the analytics hub's scope and the various AI-driven capabilities it offers. Each point is accompanied by a relevant example to illustrate its functionality.

## Progress Tracking

| Workstream                       | Design | Develop | Integrate | Test | Scale | Release |
|----------------------------------|--------|---------|-----------|------|-------|---------|
| Explore Data Lake                |        |         |           |      |       |         |
| Midoffice RAG Assistant          |        |         |           |      |       |         |
| Frontoffice FAQ Bot              |        |         |           |      |       |         |
| Backoffice Analytics Assistant   |        |         |           |      |       |         |
| Coding Assistant                 |        |         |           |      |       |         |
| CloudOps Assistant               |        |         |           |      |       |         |
| Data Observability               |        |         |           |      |       |         |
| Business Observability           |        |         |           |      |       |         |
| Trend Dashboards                 |        |         |           |      |       |         |
| Stories                          |        |         |           |      |       |         |
| Competitive Intelligence         |        |         |           |      |       |         |
| Multimodal Assistant             |        |         |           |      |       |         |
| Log/Hotspot Awareness            |        |         |           |      |       |         |
| Data Lake Guidance Advisor       |        |         |           |      |       |         |
