#!/bin/bash
set -m
# Start the primary process and put it in the background
python3 -m http.server 8080 &
# Start the rasa process
python3 -m rasa run --cors "*" --enable-api