from whoosh import index
from whoosh.qparser import MultifieldParser, OrGroup
from whoosh.scoring import BM25F
import itertools
from whoosh.scoring import WeightingModel, Weighting
from whoosh import scoring
from whoosh.reading import IndexReader
from math import log

class BinaryTFIDFScoring(WeightingModel):
    def scorer(self, searcher, fieldname, text, qf=1):
        return self.BinaryTFIDFScorer(searcher.reader(), fieldname, text)

    class BinaryTFIDFScorer(Weighting):
        def __init__(self, reader: IndexReader, fieldname, text):
            self.reader = reader
            self.fieldname = fieldname
            self.text = text
            self.max_doc = reader.doc_count_all()

            # Calculate IDF
            df = reader.doc_frequency(fieldname, text)
            idf = log((self.max_doc + 1) / (df + 1)) + 1  # Using log base e
            self.idf = idf

        def score(self, matcher):
            # Binary TF (1 if the term appears in the document, 0 otherwise)
            tf = 1 if matcher.weight() > 0 else 0
            # Calculate TF-IDF score with binary TF
            return tf * self.idf

        def max_quality(self, matcher=None):
            # Return the maximum score this scorer can produce, which is the IDF for binary TF
            return self.idf

def search(queries, n=9):
    if not hasattr(search, "ix"):
        search.ix = index.open_dir("whoosh_index")
        search.parser = MultifieldParser(fieldnames=["text"], schema=search.ix.schema, group=OrGroup.factory(0.7))

    # Parse the query
    parsed_query = search.parser.parse("\n".join(queries))
   
    # Create a searcher
    with search.ix.searcher(weighting=BinaryTFIDFScoring()) as searcher:
        # Perform the search using MMR
        results = searcher.search(parsed_query, limit=None)  # `limit=None` for all matching results
        
        # Prepare the results with scores
        scored_results = [{"docnum": result.docnum, "score": result.score, "section": result['section'], "chapter": result['chapter'], "text": result['text'], "code": result['code'], "hs4": result['code'][:4], "hs6":f"{result['code'][:4]}.{result['code'][4:6]}"} for result in results if result.score > 0.2]

    # Return the search results in descending order of relevance
    # Sorting is not required here since results are already sorted by score, but kept for clarity
    return list(itertools.islice(sorted(scored_results, key=lambda r: r['score'], reverse=True), n))

if __name__ == "__main__":
    search_results = search(["solar cells"])
    for result in search_results:
        print(result)
