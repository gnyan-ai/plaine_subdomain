import os
import pandas as pd
from whoosh.index import create_in
from whoosh.fields import Schema, TEXT
from IPython.display import display

# Define the schema for the Whoosh index
schema = Schema(
    id=TEXT(stored=True),
    section=TEXT(stored=True),
    chapter=TEXT(stored=True),
    code=TEXT(stored=True),
    text=TEXT(stored=True),
)

# Create the Whoosh index
index_dir = 'whoosh_index'
if not os.path.exists(index_dir):
    os.mkdir(index_dir)
    ix = create_in(index_dir, schema)
    # Open the index writer
    writer = ix.writer()
    # Read the CSV file into a pandas DataFrame
    df = pd.read_csv('datasets/hs_descriptions.csv', dtype=str).fillna('')
    # Index each row of the DataFrame
    for i, row in df[['Section', 'Chapter', 'Code', 'HierarchicDescription']].fillna('').astype(str).iterrows():
        writer.add_document(
            id=str(i),
            section=row['Section'],
            chapter=row['Chapter'],
            code=row['Code'],
            text=' '.join([row['HierarchicDescription']])
        )

    # Commit the changes and close the writer
    writer.commit()