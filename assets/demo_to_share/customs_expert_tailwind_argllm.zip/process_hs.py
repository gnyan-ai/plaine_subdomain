import pandas as pd
from IPython.display import display

codes = pd.read_csv('datasets/hs_codes.csv', dtype=str, usecols=['Section','Chapter','HS8'])
codes['HS2'] = codes['HS8'].apply(lambda x: str(str(int(float(x))).zfill(8))[:2] if pd.notna(x) else x)
codes.drop(columns=['HS8'], inplace=True)
codes.drop_duplicates(subset=['HS2'], inplace=True)
descriptions = pd.read_csv('datasets/feed_to_rag.csv', dtype=str, usecols=['Code', 'HierarchicDescription'])
descriptions['HS2'] = descriptions['Code'].apply(lambda x: str(str(int(float(x))).zfill(8))[:2] if pd.notna(x) else x)
code_descriptions = descriptions.merge(codes, how='left', left_on='HS2', right_on='HS2')
code_descriptions.fillna('').astype(str).to_csv('datasets/hs_descriptions.csv', index=False)
display(code_descriptions)