import os
import pandas as pd
from IPython.display import display
from langchain_community.document_loaders import DataFrameLoader
from langchain.vectorstores import FAISS
from langchain.vectorstores import VectorStore
from langchain.embeddings import SentenceTransformerEmbeddings

# Create the chroma index
index_dir = 'faiss_db'
if not os.path.exists(index_dir):
    def create_vectorstore():
        hts_df = pd.read_csv('datasets/hs_descriptions.csv', dtype=str).fillna('')
        pdf = hts_df[['Section', 'Chapter', 'Code', 'HierarchicDescription']]
        index_data(pdf.fillna('').astype(str))

    def index_data(pdf):
        loader = DataFrameLoader(pdf, page_content_column="HierarchicDescription",)
        documents = loader.load()
        if not hasattr(index_data, 'embedding_function'):
            index_data.embedding_function = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")
        db = FAISS.from_documents(documents, index_data.embedding_function)
        db.save_local(index_dir)
        return db
    
def get_vectordb(path_to_save_chroma=index_dir):
    from langchain.embeddings import SentenceTransformerEmbeddings
    if not hasattr(get_vectordb, 'embedding_function'):
        get_vectordb.embedding_function = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")
    if not hasattr(get_vectordb, 'vectordb'):
        from langchain.vectorstores import FAISS
        get_vectordb.vectordb = FAISS.load_local(path_to_save_chroma, get_vectordb.embedding_function)
    return get_vectordb.vectordb

def search_embeddings(query, k=9):
    vectordb = get_vectordb()
    results = vectordb.similarity_search("\n".join(query), k,)
    scored_results = [{"docnum": docnum + 1, "score": 1.0, "section": result.metadata['Section'], "chapter": result.metadata['Chapter'], "text": result.page_content, "code": result.metadata['Code'], "hs4": result.metadata['Code'][:4], "hs6":f"{result.metadata['Code'][:4]}.{result.metadata['Code'][4:6]}"} for docnum, result in enumerate(results)]
    return scored_results
    
if __name__ == '__main__':
    print(search_embeddings(['drones']))