from flask import Flask, render_template, request, jsonify
from llm_model.augmenter import get_keywords, explain_rag
import index_text, search_index, index_embeddings
import pandas as pd
app = Flask(__name__)



@app.route("/")
@app.route("/index")
def index():
	return render_template("index.html")

def search_text(query):
	search_results = pd.DataFrame.from_records(search_index.search(query))
	return search_results

def search_embeddings(query):
	search_results = pd.DataFrame.from_records(index_embeddings.search_embeddings(query))
	return search_results

@app.route("/expand_query", methods=['POST'])
def expand():
	import json
	search_query = request.json['query']
	text_search = request.json['text_search'] if 'text_search' in request.json else False
	if search_query:
		search_query = search_query[:128]
		expanded_queries = [search_query] + get_keywords(search_query)
		fn = search_text if text_search else search_embeddings
		results_df = fn(expanded_queries[1:] if len(expanded_queries) > 1 else expanded_queries)
		results_df['text'] = results_df['text'].apply(lambda x: x[:256])
		rag_explanations = explain_rag(json.dumps(expanded_queries), results_df[['code', 'text']].head(9).to_json(orient='records') if results_df is not None else '')
		code = rag_explanations['code'] if 'code' in rag_explanations else ''
		codes = results_df.set_index('code') if code and results_df is not None else None
		section = codes.loc[code]['section'] if codes is not None and code in codes.index else ''
		chapter = codes.loc[code]['chapter'] if codes is not None and code in codes.index else ''
		rag_explanations.update({'section': section, 'chapter': chapter})
		results = {"phrases": expanded_queries, "results": results_df.to_dict(orient='records') if results_df is not None else [], "explanation":rag_explanations}
		return jsonify(results)
	else:
		return jsonify({"phrases": [], "results": [], "explanation":""})
	
@app.route("/search")
def search_page():
	return render_template("search.html")

if __name__ == '__main__':
	app.run(debug=True)